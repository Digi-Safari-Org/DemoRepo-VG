# Copilot Prompt Guide: Modernizing Legacy Codebases (JS)

This guide provides effective prompts for using GitHub Copilot to modernize and secure your legacy Node.js application as described in the lab scenario.

---

## 1. Refactor Synchronous and Callback Code

- "Refactor this function using async/await for Node.js 20.x."
- "Convert all callback-based functions in this file to use async/await."
- "Identify and modernize any blocking or synchronous code."

## 2. Replace Deprecated APIs

- "Replace deprecated Node.js APIs (like http.get) with modern alternatives."
- "Migrate from http.get to native fetch or axios with async/await."
- "Update this code to use the latest HTTP client best practices."

## 3. Improve Security and Error Handling

- "Add try-catch blocks to all async functions for robust error handling."
- "Suggest security improvements for this function."
- "How can I validate user input and handle timeouts securely in this code?"
- "Replace any insecure hash or crypto usage with modern, secure alternatives."

## 4. Update Dependencies

- "Suggest the latest secure versions for all dependencies in package.json."
- "Update package.json to use the most recent versions of axios, express, etc."
- "Are there any deprecated or vulnerable packages in this project?"

## 5. Bonus: Add a Modern Endpoint

- "Add a new async endpoint that fetches data from an external API using fetch and proper error handling."
- "Demonstrate good logging and error handling in a new async route."

## 6. Documentation and Migration Report

- "Document all code changes and the reasoning behind them for migration_report.md."
- "Summarize the main improvements made during the migration."

---

Use these prompts in Copilot Chat or inline to accelerate your migration and ensure your codebase is secure, modern, and maintainable.
