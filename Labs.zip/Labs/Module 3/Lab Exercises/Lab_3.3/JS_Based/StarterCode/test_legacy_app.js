/**
 * Test suite for legacy_app.js.
 * Initially some tests will fail until modernization is complete.
 * Run with: `npm test`
 */

const assert = require('assert');
const { processData, fetchItems, calculateDiscount } = require('./legacy_app');

describe('processData', () => {
    it('should return uppercase strings', () => {
        const input = ['apple', 'banana', 'cherry'];
        const result = processData(input);
        assert.ok(result.every(item => typeof item === 'string'), "All items must be strings");
        assert.deepStrictEqual(result, ['APPLE', 'BANANA', 'CHERRY']);
    });
});

describe('fetchItems', () => {
    it('should return an array of objects with `item` keys', () => {
        const items = fetchItems(3);
        assert.ok(Array.isArray(items), "Expected array");
        assert.strictEqual(items.length, 3);
        assert.ok(items.every(obj => obj.hasOwnProperty('item')), "Every object must have `item` key");
    });
});

describe('calculateDiscount', () => {
    it('should correctly apply discount and return float', () => {
        const price = 100;
        const discountRate = 0.2;
        const discounted = calculateDiscount(price, discountRate);
        assert.strictEqual(discounted, 80);
        assert.strictEqual(typeof discounted, 'number');
    });
});
