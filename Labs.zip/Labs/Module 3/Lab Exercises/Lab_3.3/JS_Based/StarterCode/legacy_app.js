/**
 * Legacy Application - Node.js 14.x Style
 * ---------------------------------------
 * This script uses outdated callbacks, blocking calls,
 * deprecated libraries, and weak security practices.
 * Your task:
 * 1. Upgrade to Node.js 20.x async/await compatibility.
 * 2. Replace deprecated or insecure APIs.
 * 3. Apply updated security best practices.
 * 4. Ensure all tests pass.
 */

const http = require('http'); // Deprecated in favor of fetch/axios
const crypto = require('crypto');
const fs = require('fs'); // Blocking file I/O for demo

// --- Old-style HTTP fetch ---
function fetchData(url, callback) {
    http.get(url, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => callback(null, data));
    }).on('error', (err) => {
        callback(err);
    });
}

// --- Weak password hashing ---
function hashPassword(password) {
    return crypto.createHash('md5').update(password).digest('hex');
}

// --- Blocking data processing ---
function processData(data) {
    // Legacy: returns items without formatting
    const result = [];
    for (let item of data) {
        result.push(String(item)); // No uppercase conversion
    }
    return result;
}

// --- Fake DB fetch (blocking) ---
function fetchItems(limit = 5) {
    // Simulates latency
    const start = Date.now();
    while (Date.now() - start < 1000) {} // Blocking sleep
    return Array.from({ length: limit }, (_, i) => ({ item: `legacy_item_${i}` }));
}

// --- Simple discount calc ---
function calculateDiscount(price, discountRate) {
    return price - (price * discountRate); // No validation
}

// --- Demo execution ---
function main() {
    console.log("Legacy app running...");

    fetchData('http://example.com', (err, data) => {
        if (err) {
            console.error("Error fetching data:", err);
            return;
        }
        console.log("Fetched data length:", data.length);
    });

    console.log("Password hash:", hashPassword('SuperSecret123'));
    console.log("Processed data:", processData(['apple', 'banana', 'cherry']));
    console.log("Fetched items:", fetchItems(3));
    console.log("Discounted price:", calculateDiscount(100, 0.2));
}

if (require.main === module) {
    main();
}

module.exports = { processData, fetchItems, calculateDiscount };
