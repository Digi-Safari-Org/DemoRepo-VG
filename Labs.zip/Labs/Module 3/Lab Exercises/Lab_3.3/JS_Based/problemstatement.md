  # Lab: Modernizing Legacy Codebases with Version-Aware Copilot Suggestions (JS)

  ## Objective
  You will modernize a legacy JS app by:
  - Upgrading deprecated APIs and patterns to be compatible with **Node.js 20.x**
  - Refactoring code to follow updated **security best practices**
  - Migrating synchronous code to **async/await** where beneficial
  - Documenting **all changes and reasoning** in `migration_report.md`

  ---

  ## Scenario
  You have inherited a legacy JavaScript application running on **Node.js 14.x**.  
  Your organization is moving to **Node.js 20.x** and must ensure:
  1. All deprecated APIs are removed.
  2. Code is optimized for new **async/await** capabilities.
  3. Security vulnerabilities are fixed (e.g., unsafe child_process calls, outdated hash functions).
  4. Future developers can understand why changes were made.
  ---

  ## Files Provided
  - legacy_app.js — Old implementation.
  - package.json 
  - test_legacy_app.js — Unit tests (some may fail initially).
  - migration_report.md — Where you’ll log your migration notes.

  ---

  ## Tasks:

  ### Step 1: Analyze and Modernize Async Code
  - Open `legacy_app.js`
  - Look for synchronous functions or callback-based functions that would benefit from async/await patterns.
  - Use Copilot to:
    - Convert blocking calls to async functions
    - Suggest proper use of `await` where needed

  ### Step 2: Migrate Deprecated APIs
  - The code uses `http.get()` and older callback patterns.
  - Prompt Copilot to:
    - Replace deprecated Node.js patterns
    - Use modern HTTP libraries like `axios` or native `fetch`

  ### Step 3: Improve Security and Error Handling
  - Ask Copilot to:
    - Add try-catch blocks where missing
    - Suggest secure coding best practices (e.g., timeout handling, input validation)

  ### Step 4: Update Dependencies
  - Open `package.json` 
  - Prompt Copilot to suggest latest secure versions for libraries like `axios`, `express`, etc.
  - Update and re-run tests to confirm everything works.

  ---

  ## Sample Prompts to Try with Copilot

  > "Refactor this function using Node.js 20.x async/await features."

  > "Replace deprecated Node.js usage with current best practices."

  > "Update to modern HTTP client with better performance and timeout handling."

  > "What security improvements should I make in this function?"

  ---

  ## Bonus Challenge:
  Add a new endpoint to your `legacy_app.js` that:
  - Uses async HTTP requests
  - Follows updated conventions
  - Demonstrates good error handling and logging

  ---

  ## Success Criteria:
  - All deprecated code patterns are replaced.
  - Code conforms to Node.js 20.x async/await standards.
  - Updated package versions.
  - All unit tests pass.
  - Secure and readable codebase.

