# Copilot Prompt Guide for Lab 3.3: Migrating and Testing Legacy Apps with Copilot Enterprise

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the migration and testing tasks in Lab 3.3. Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity.

---

## Prompts for Migrating Legacy App (`Starter Code/legacy_app.py`)

### 1. Analyze and Suggest Migration Steps
**Prompt:**
> Analyze `legacy_app.py` and suggest a step-by-step migration plan to modern Python standards. Identify deprecated patterns and recommend replacements.

### 2. Refactor for Modularity and Maintainability
**Prompt:**
> Refactor this legacy code to improve modularity, readability, and maintainability. Add type hints and Google-style docstrings to all functions.

### 3. Address Migration Report Findings
**Prompt:**
> Review `migration_report.md` and apply the recommended changes to `legacy_app.py`. What additional improvements can be made?

---

## Prompts for Testing (`Starter Code/test_legacy_app.py`)

### 1. Review and Expand Tests
**Prompt:**
> Review the tests for coverage and reliability. Add new tests for migrated functions and edge cases.

### 2. Fix and Modernize Test Logic
**Prompt:**
> Refactor any outdated or flaky test logic. Ensure all tests are deterministic and robust.

---

## Prompts for Requirements and Dependencies (`Starter Code/requirements.txt`)

### 1. Update Dependencies
**Prompt:**
> Review `requirements.txt` and update dependencies to the latest compatible versions. Remove unused or deprecated packages.

---

## Cross-File Context Prompts

### 1. Usage Analysis and Modularization
**Prompt:**
> How do changes in `legacy_app.py` affect the tests and dependencies? Suggest improvements for modularity and maintainability across files.

### 2. Apply Team Standards
**Prompt:**
> Apply our team's migration and testing standards to all code in this project. What changes are needed?

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```python
# Refactor for modularity and clarity
# Add type hints and docstrings
# Address migration report recommendations
# Expand tests for migrated functions
# Update dependencies as needed
```

---

## Tips
- Open all relevant files for best results.
- Use Copilot Chat to ask about cross-file logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---
