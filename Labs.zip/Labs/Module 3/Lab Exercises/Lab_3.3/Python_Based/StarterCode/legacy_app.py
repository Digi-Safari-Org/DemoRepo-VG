"""
Legacy Application - Python 3.6 Style
--------------------------------------
This script uses outdated syntax, blocking calls, deprecated libraries, 
and weak security practices. Your task:

1. Upgrade the code for Python 3.12 compatibility.
2. Replace deprecated or insecure APIs.
3. Refactor blocking calls into async (where relevant).
4. Apply updated security best practices.

You should use GitHub Copilot's **version-aware suggestions** to guide
this modernization process.
"""

import asyncio
import requests  # Deprecated for async use in modern Python
import hashlib
import time


# --- Old-Style Coroutines ---
@asyncio.coroutine
def fetch_data(url):
    """Fetch data from URL (old generator-based coroutine)."""
    response = requests.get(url)  # Blocking call
    return response.text


# --- Weak password hashing ---
def hash_password(password):
    """Hashes password using MD5 (weak, insecure)."""
    return hashlib.md5(password.encode()).hexdigest()


# --- Outdated string formatting ---
def greet_user(username):
    """Greet user using old-style formatting."""
    print("Hello %s, welcome back!" % username)


# --- Missing Functions for Tests (Outdated Implementations) ---
def process_data(data):
    """
    Legacy: Returns the same data without proper formatting.
    Expected modernization:
      - Convert all items to uppercase strings.
      - Use Pythonic list comprehensions.
    """
    result = []
    for item in data:
        result.append(str(item))  # No uppercase conversion
    return result


def fetch_items(limit=5):
    """
    Legacy: Simulate fetching items with blocking sleep.
    Expected modernization:
      - Use async HTTP calls or non-blocking I/O.
    """
    time.sleep(1)  # Blocking call
    return [{"item": f"legacy_item_{i}"} for i in range(limit)]


def calculate_discount(price, discount_rate):
    """
    Legacy: Applies discount without validation.
    Expected modernization:
      - Validate inputs.
      - Ensure float precision.
    """
    return price - (price * discount_rate)


# --- Main Execution ---
def main():
    start = time.time()

    loop = asyncio.get_event_loop()
    data = loop.run_until_complete(fetch_data("https://example.com"))
    print("Data fetched:", data[:50], "...")

    hashed = hash_password("SuperSecret123")
    print("Stored password hash:", hashed)

    greet_user("Alice")

    # Demo: Use legacy functions
    sample_data = ["apple", "banana", "cherry"]
    print("Processed data:", process_data(sample_data))
    print("Fetched items:", fetch_items(3))
    print("Discounted price:", calculate_discount(100, 0.2))

    print("Execution Time: {:.2f} seconds".format(time.time() - start))


if __name__ == "__main__":
    main()
