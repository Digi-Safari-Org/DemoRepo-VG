"""
Test suite for legacy_app.py.

Your modernization tasks:
1. Upgrade legacy_app.py for Python 3.12 compatibility.
2. Refactor outdated code so all tests pass.
3. Ensure async, security, and best practice improvements are applied.
"""

import pytest
from legacy_app import process_data, fetch_items, calculate_discount


def test_process_data_returns_uppercase_strings():
    input_data = ["apple", "banana", "cherry"]
    result = process_data(input_data)
    assert all(isinstance(item, str) for item in result), "All items must be strings"
    assert result == ["APPLE", "BANANA", "CHERRY"], (
        f"Expected all uppercase strings, got: {result}"
    )


def test_fetch_items_returns_list_of_dicts_with_item_key():
    items = fetch_items(limit=3)
    assert isinstance(items, list), f"Expected a list, got {type(items).__name__}"
    assert len(items) == 3, f"Expected 3 items, got {len(items)}"
    assert all("item" in itm for itm in items), (
        f"Each item must contain the key 'item', got: {items}"
    )


def test_calculate_discount_applies_correctly():
    price = 100
    discount_rate = 0.2
    discounted_price = calculate_discount(price, discount_rate)
    assert discounted_price == 80, (
        f"Expected 80 after 20% discount, got {discounted_price}"
    )
    assert isinstance(discounted_price, float), (
        f"Expected result type float, got {type(discounted_price).__name__}"
    )
