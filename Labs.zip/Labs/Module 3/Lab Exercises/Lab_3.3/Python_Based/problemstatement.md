# Lab: Modernizing Legacy Codebases with Version-Aware Copilot Suggestions

## Objective
You will modernize a legacy Python app by:
- Upgrading deprecated APIs and patterns to be compatible with **Python 3.12**
- Refactoring code to follow updated **security best practices**
- Migrating synchronous code to **async** where beneficial
- Documenting **all changes and reasoning** in `migration_report.md`

---

## Scenario
You have inherited a legacy Python application running on **Python 3.8**.  
Your organization is moving to **Python 3.12** and must ensure:
1. All deprecated APIs are removed.
2. Code is optimized for new async capabilities.
3. Security vulnerabilities are fixed (e.g., unsafe subprocess calls, outdated hash functions).
4. Future developers can understand why changes were made.
---

## Files Provided
- legacy_app.py — Old implementation.
- requirements.txt — Dependencies for running and testing.
- test_legacy_app.py — Unit tests (some may fail initially).
- migration_report.md — Where you’ll log your migration notes.


---

## Tasks:

### Step 1: Analyze and Modernize Async Code
- Open `legacy_app.py`
- Look for synchronous functions that would benefit from async patterns.
- Use Copilot to:
  - Convert blocking calls to `async def`
  - Suggest proper use of `await` where needed

### Step 2: Migrate Deprecated APIs
- The code uses `asyncio.get_event_loop()` and older HTTP libraries.
- Prompt Copilot to:
  - Replace deprecated asyncio patterns
  - Use modern HTTP libraries like `httpx` or `aiohttp`

### Step 3: Improve Security and Error Handling
- Ask Copilot to:
  - Add try-except blocks where missing
  - Suggest secure coding best practices (e.g., timeout handling, input validation)

### Step 4: Update Dependencies
- Open `requirements.txt`
- Prompt Copilot to suggest latest secure versions for libraries like `requests`, `flask`, etc.
- Update and test accordingly.

### Step 5: Implement Missing Functions
- The provided `test_legacy_app.py` references functions `process_data`, `fetch_items`, and `calculate_discount` that are not present in `legacy_app.py`.
- Implement these functions using Copilot, ensuring:
  - `process_data(data: list)` returns a list of uppercase strings.
  - `fetch_items(limit: int)` returns a list of dictionaries containing at least `"item"` keys.
  - `calculate_discount(price: float, discount_rate: float)` applies the discount and returns the final price as a float.

**Tip:** Run `pytest` after completing the above steps. All tests in `test_legacy_app.py` should pass on Python 3.12.
---

## Sample Prompts to Try with Copilot

> "Refactor this function using Python 3.12 async features."

> "Replace deprecated asyncio usage with current best practices."

> "Update to modern HTTP client with better performance and timeout handling."

> "What security improvements should I make in this function?"

---

## Bonus Challenge:
Add a new endpoint to your `legacy_api.py` that:
- Uses async HTTP requests
- Follows updated conventions
- Demonstrates good error handling and logging

---

## Success Criteria:
- All deprecated code patterns are replaced.
- Code conforms to Python 3.12 async standards.
- Updated package versions.
- Secure and readable codebase.




