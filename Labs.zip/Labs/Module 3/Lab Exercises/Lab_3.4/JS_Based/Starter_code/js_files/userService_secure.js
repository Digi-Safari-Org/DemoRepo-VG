// userService_secure.js
// Secure version to be implemented by students using bcrypt hashing.

const db = require("./db");

/**
 * Creates a new user securely.
 * TODO: Implement password hashing before storing.
 */
function createUser(username, password) {
    throw new Error("Not implemented. Use bcrypt to hash passwords.");
}

/**
 * Logs in a user securely.
 * TODO: Compare hashed passwords and migrate old plain-text users on login.
 */
function loginUser(username, password) {
    throw new Error("Not implemented. Compare with hashed password.");
}

module.exports = { createUser, loginUser };
