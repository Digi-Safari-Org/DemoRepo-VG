// demo.js
// Demonstrates insecure password handling for lab setup.

const { createUser, loginUser } = require("./userService_insecure");

function runDemo() {
    console.log("Creating user 'alice' with password 'password123'...");
    createUser("alice", "password123");

    console.log("Attempting login with correct credentials...");
    console.log(loginUser("alice", "password123")); // Expected: true

    console.log("Attempting login with incorrect credentials...");
    console.log(loginUser("alice", "wrongpassword")); // Expected: false
}

if (require.main === module) {
    runDemo();
}
