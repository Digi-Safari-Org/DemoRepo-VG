# Copilot Prompts and Lab Steps for Module 3

## Lab 3.4: Pull Request Suggestions for Security Vulnerabilities in Multi-Service Repos (JavaScript Version)

**Copilot Prompt:**
```
A code review flagged that passwords are stored in plain text in the user-service microservice. Use Copilot Chat to:
1. Search for all password handling in the user-service folder.
2. Identify where plain-text passwords are stored.
3. Refactor the code to use secure password hashing (e.g., bcrypt).
4. Draft a Pull Request with:
   - A clear title
   - Detailed description of the changes
   - References to security standards (e.g., OWASP Top 10)
```

**Steps to Complete:**
1. Open `Lab_3.4/userService_insecure.js` and `userService_secure.js`.
2. Use Copilot Chat to search for all password handling and storage logic.
3. Identify and highlight any code that stores passwords in plain text.
4. Refactor the code to use a secure password hashing library (e.g., bcrypt) before storing passwords.
5. Update any related code (e.g., user creation, authentication) to use hashed passwords.
6. Draft a Pull Request with:
   - Title: e.g., "Fix: Secure Password Storage with Bcrypt Hashing"
   - Description: Explain the vulnerability, the fix, and reference security standards (OWASP Top 10: A3 Sensitive Data Exposure).
7. Ensure all tests pass and the new logic is covered.

---

