def create_user(username, password):
    # TODO: Replace plain text storage with secure hashing
    db.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
    return {"status": "success", "user": username}