
## Lab 3.5: Bug Detection and Fix Based on Tech Stack Version Updates

**Copilot Prompt:**
```
The payment processing microservice uses the deprecated Stripe API: stripe.Charge.create. Use Copilot Chat to:
1. Scan the repo for all uses of stripe.Charge.create.
2. Draft a GitHub Issue explaining the business impact, affected files, and recommended fix.
3. Refactor the code to use stripe.PaymentIntent.create instead.
4. Add or update unit tests to verify the new payment logic.
```

**Steps to Complete:**
1. Open `Lab_3.5/stripe-payment-service_2/payment_service.py` and related files.
2. Use Copilot Chat to search for all instances of `stripe.Charge.create`.
3. Confirm the deprecation in Stripe's official API documentation.
4. Draft a GitHub Issue with:
   - Title: e.g., "Bug: Deprecated Stripe Charges API Used in Payment Service"
   - Description: Business impact, affected files, and recommended fix.
5. Refactor the code to use `stripe.PaymentIntent.create` for payment processing.
6. Update or add unit tests in `test_payment_service.py` to cover all payment scenarios.
7. Run tests to ensure the new logic works as expected.
