# Lab 3.5: Bug Detection and Fix Based on Tech Stack Version Updates

### Objectives:
    - Use GitHub Copilot Chat to detect deprecated API calls in a large codebase.
    - Generate a detailed bug report using Copilot in GitHub Issues.
    - Implement fixes that are compatible with the latest version of your tech stack.

### Scenario:
Your payment processing microservice still uses a deprecated Stripe API (`stripe.Charge.create`), which will be removed in the next API version (`2025-08-15`). This can cause production outages if not updated.

You must:
1. Detect deprecated API usage across the repo.
2. Create a GitHub Issue with Copilot that:
   - Explains the problem in business terms.
   - Shows where and how the API is used.
   - Suggests the recommended fix.
3. Update the code to use the latest PaymentIntent API.

### Instructions:

Part 1 — Detecting Deprecated APIs
1. Use Copilot Chat to scan the repo for any usage of `stripe.Charge.create`.
2. Verify that the API is indeed deprecated by checking Stripe’s latest API docs.

Part 2 — Creating the Bug Report
1. In GitHub Issues, use Copilot to:
   - Write a clear, actionable bug report.
   - Include affected files and line numbers.
   - Add “Steps to Reproduce” and “Expected Behavior” sections.
   - Include API doc reference links.

Part 3 — Updating to the Latest API
1. Refactor the code to use `stripe.PaymentIntent.create` instead.
2. Ensure the migration handles all previous payment scenarios (currency, description, amount, payment method).
3. Add unit tests for the updated logic.

#### Starter Code Snippet:
```python
import stripe

def process_payment(amount, currency="usd", payment_method=None):
    # Deprecated method - needs to be updated
    return stripe.Charge.create(
        amount=amount,
        currency=currency,
        source=payment_method,
        description="Order Payment"
    )
```