
## Lab 3.5: Bug Detection and Fix Based on Tech Stack Version Updates (JavaScript Version)

**Copilot Prompt:**
```
The payment-service microservice uses the deprecated Stripe API: stripe.charges.create. Use Copilot Chat to:
1. Scan the payment-service folder for all uses of stripe.charges.create.
2. Draft a GitHub Issue explaining the business impact, affected files, and recommended fix.
3. Refactor the code to use stripe.paymentIntents.create instead.
4. Add or update unit tests to verify the new payment logic.
```

**Steps to Complete:**
1. Open `Lab_3.5/payment.js` and related files.
2. Use Copilot Chat to search for all instances of `stripe.charges.create`.
3. Confirm the deprecation in Stripe's official API documentation.
4. Draft a GitHub Issue with:
   - Title: e.g., "Bug: Deprecated Stripe Charges API Used in Payment Service"
   - Description: Business impact, affected files, and recommended fix.
5. Refactor the code to use `stripe.paymentIntents.create` for payment processing.
6. Update or add unit tests in `payment.test.js` to cover all payment scenarios.
7. Run tests to ensure the new logic works as expected.
