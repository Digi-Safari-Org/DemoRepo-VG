const stripe = require('stripe')('your_stripe_secret_key');

async function processPayment(amount, currency = 'usd', paymentMethod) {
    // Deprecated method - needs to be updated
    return await stripe.charges.create({
        amount: amount,
        currency: currency,
        source: paymentMethod,
        description: 'Order Payment'
    });
}

// Example usage
processPayment(5000, 'usd', 'pm_card_visa')
    .then(res => console.log(res))
    .catch(err => console.error(err));