
# Lab 3.1 (JS): Full Developer Workflow with Copilot Chat

## Scenario
You are working in a large internal JS repo. Your goal is to use GitHub Copilot’s context awareness to refactor and test a flaky calculator module, and to practice a full developer workflow including code review and issue reporting.

## Folder Structure
```
Starter Code/
├── calculator.js       # Contains legacy code to refactor
├── test_calculator.js  # Unit tests (1 test will fail)
└── README.md           # Instructions
```

## Tasks

**Step 1: Refactor the Legacy Function**
- Open `calculator.js` and locate the legacy functions (e.g., `divide`).
- Use Copilot inline suggestions or chat to refactor for reliability and clarity, handling edge cases (e.g., division by zero).
- Ensure functions return consistent responses for invalid inputs.

**Prompt Suggestion:**
```
Refactor this legacy divide function to avoid division by zero and return a clear message or fallback value when denominator is zero.
```

**Step 2: Run the Tests**
```
npm test test_calculator.js
```
*Note: One test will fail intentionally for the next step.*

**Step 3: Draft a Pull Request with Copilot**
1. Stage your changes:
	```
	git add calculator.js
	```
2. Commit your changes:
	```
	git commit -m "Refactor calculator functions"
	```
3. Push to a new branch and create a Pull Request via the GitHub UI.
4. Use Copilot PR Suggestions to fill in the title and description.

**Prompt Suggestion:**
```
Generate a PR title and summary based on my recent commit that refactored calculator functions to handle edge cases.
```

**Step 4: File a Copilot-Assisted Issue Report**
1. Open the failing test (`test_calculator.js`) and identify the root cause.
2. Use Copilot Chat to explain the failure and suggest a structured issue report.

**Prompt Suggestion:**
```
Generate a structured GitHub issue report for a failing unit test in test_calculator.js. Include expected vs actual behavior, possible cause, and steps to reproduce.
```
3. Create a new GitHub issue using Copilot’s generated content.

---

## ✨ Goal

```
add(2, 3) // ➞ 5
subtract(5, 3) // ➞ 2
```
