// test_calculator.js
// Tests for calculator module 
const { add, subtract } = require('../flaky_module/calculator');

describe('Calculator Tests', () => {
    it('should add numbers', () => {
        expect(add(2, 3)).toBe(5);
        expect(add(-1, 1)).toBe(0);
    });

    it('should subtract numbers', () => {
        expect(subtract(5, 3)).toBe(2);
        expect(subtract(0, 1)).toBe(-1);
    });
});
