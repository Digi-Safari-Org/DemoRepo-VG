
---

### 📄 `README_prompts.md`
```md
# 🧠 Prompt Examples for Copilot

## 🔧 Refactoring Help

> “Refactor the `divide` function to handle division by zero safely.”

## 📦 Pull Request Prompts

> "Generate a pull request title and description for changes in calculator.py."

> "Summarize the main change in calculator.py in a PR description."

## 🐛 Issue Reporting Prompts

> "A test failed due to divide by zero. Generate a bug report issue with expected vs actual output."

> "Help triage the divide test failure and suggest code changes."

## 🛠️ Fix Suggestions

> "What is the best way to fix this flaky divide test case?"

> "Update the divide function to handle division by zero and avoid crashes."

---
