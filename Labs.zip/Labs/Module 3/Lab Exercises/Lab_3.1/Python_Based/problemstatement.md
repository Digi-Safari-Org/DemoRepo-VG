# Lab: AI-Driven Code Review and Issue Reporting Workflow

## Scenario
You’ve joined a backend tools team maintaining a flaky module. Your goal is to refactor a function using Copilot, create a PR with Copilot’s help, and respond to a simulated test failure by filing an issue report—also Copilot-assisted.

### Overview
In this lab, you’ll simulate a full developer workflow using GitHub Copilot Enterprise features to refactor code, create pull requests, and file bug reports. You’ll leverage Copilot Chat, PR suggestions, and structured prompt engineering to create efficient development and reporting workflows.

### Learning Objectives
By the end of this lab, learners will:

- Refactor code with the help of GitHub Copilot.
- Use Copilot to generate meaningful PR titles and descriptions.
- Simulate a failing test scenario and generate a structured issue report.
- Use Copilot to assist with bug triaging and root cause exploration.

Folder structure:
```
Starter Code/
├── flaky_module/
│   └── calculator.py       # Contains legacy code to refactor
├── tests/
│   └── test_calculator.py  # Unit tests (1 test will fail)
└── README.md               # Instructions
```

#### Lab Tasks
 **Step 1:** Refactor the Legacy Function

**File**: flaky_module/calculator.py

- Open the file and locate the legacy divide function.
- Use a Copilot inline suggestion or chat prompt to refactor the function to handle edge cases (e.g., division by zero).
- Ensure the function returns a consistent response for invalid inputs.

**Prompt Suggestion:**
```
Refactor this legacy divide function to avoid ZeroDivisionError and return a clear message or fallback value when denominator is zero.
```

**Step 2: Run the Tests**
```
pytest tests/test_calculator.py
```
#### Note: 
You’ll notice that 1 test fails. This is intentional and will be used in the next step.

**Step 3: Draft a Pull Request with Copilot**
1. Stage your changes:
    ```
    git add flaky_module/calculator.py
    ```

2. Commit your changes:
    ```
    git commit -m "Refactor divide function"
    ```

3. Push to a new branch and create a Pull Request via the GitHub UI.
4. Use Copilot PR Suggestions (in the GitHub PR UI) to automatically fill in the title and description.

**Prompt Suggestion:**
    
```
Generate a PR title and summary based on my recent commit that refactored a divide function to handle division by zero.
```

**Step 4: File a Copilot-Assisted Issue Report**
1. Open the failing test (test_calculator.py) and identify the root cause.
2. Use Copilot Chat to explain the failure and suggest a structured issue report.

**Prompt Suggestion:**
```
Generate a structured GitHub issue report for a failing unit test in test_calculator.py. Include expected vs actual behavior, possible cause, and steps to reproduce.
```
3. Create a new GitHub issue using Copilot’s generated content.


