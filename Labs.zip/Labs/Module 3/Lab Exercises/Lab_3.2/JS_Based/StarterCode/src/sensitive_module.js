'use strict';

/**
 * Sensitive crypto module — starter template.
 * Node.js v18+ required.
 *
 * TODOs for learners:
 *  1. Implement encryptData() using AES (crypto module or secure library).
 *  2. Implement decryptData() to reverse the encryption process.
 *  3. Use AES-256-GCM with a random IV and authentication tag for security.
 *  4. Consider key derivation (e.g., scrypt) if using a passphrase.
 *  5. Add optional Additional Authenticated Data (AAD) support.
 */

const crypto = require('crypto');

/**
 * Encrypt data securely.
 * @param {string|Buffer|object} plaintext - Data to encrypt.
 * @param {string|Buffer} key - 32-byte key or passphrase.
 * @param {object} [opts]
 * @returns {object} Encrypted payload.
 */
function encryptData(plaintext, key, opts = {}) {
  // TODO: implement secure AES encryption
  //  - Generate a random IV
  //  - Derive or validate the key
  //  - Create cipher
  //  - Optionally set AAD
  //  - Encrypt and return { algo, iv, tag, ciphertext, salt?, aad? }
  return {}; // placeholder
}

/**
 * Decrypt data securely.
 * @param {object} payload - Encrypted payload from encryptData().
 * @param {string|Buffer} key - 32-byte key or passphrase.
 * @returns {Buffer} Decrypted data.
 */
function decryptData(payload, key) {
  // TODO: implement secure AES decryption
  //  - Parse IV, tag, ciphertext
  //  - Derive or validate the key
  //  - Create decipher
  //  - Optionally set AAD
  //  - Decrypt and return the plaintext Buffer
  return Buffer.from(''); // placeholder
}

// Demo code (will run if executed directly: node src/sensitive_module.js)
if (require.main === module) {
  const secret = 'Top secret data 💼';
  const passphrase = 'correct horse battery staple'; // demo only

  console.log('Original:', secret);

  const encrypted = encryptData(secret, passphrase, { aad: 'lab-3.2' });
  console.log('Encrypted payload:', encrypted);

  const decrypted = decryptData(encrypted, passphrase).toString('utf8');
  console.log('Decrypted:', decrypted);
}

module.exports = { encryptData, decryptData };
