
# Lab 3.2: Auditing Copilot Usage in Regulated Dev Environments (JS)

## Objective
In this lab, you'll simulate how Copilot is used in a high-security JavaScript module and how a compliance officer can audit its interactions using **GitHub Enterprise Audit Logs.**

## Scenario
You've written code in a sensitive file using Copilot. Now, your role shifts to that of a security auditor. You’ll examine the audit logs to track what Copilot generated, who accepted/rejected suggestions, and whether secure practices were followed.

---

## Part 1: Use Copilot in Sensitive Code

1. Open `src/sensitive_module.js`.
2. Using Node.js v18+ and Copilot (inline/chat/edit modes), write:
	- An `encryptData()` function using AES crypto or a library).
	- A `decryptData()` function.
3. Commit your changes with a meaningful commit message.

---

## Part 2: Simulate Copilot Audit Log Review

1. Open `audit/sample_audit_log.json`.
2. Pretend this came from **GitHub Enterprise Audit Log**.
3. As a compliance reviewer, analyze:
	- Who used Copilot? (actor field).
	- What suggestions were accepted/rejected? (decision field).
	- Whether a weak encryption method suggested and rejected?
4. Document your findings.

---

## Optional: Create a Copilot-assisted Issue

If you find that a weak encryption method was suggested and accidentally accepted:
- Use Copilot Chat to help you write a structured GitHub Issue titled: `Potential Weak Encryption in sensitive_module.js`.

---

## Outcomes

- Understand Copilot usage traceability in enterprise audits.
- Simulate secure coding practices with compliance in mind.
