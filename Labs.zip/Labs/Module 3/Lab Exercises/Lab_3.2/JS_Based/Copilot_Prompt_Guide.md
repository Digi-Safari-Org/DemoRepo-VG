# Copilot Prompt Guide for Lab 3.2 (JS): Auditing and Refactoring Sensitive Modules

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the auditing and refactoring tasks in Lab 3.2 (JS). Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity.

---

## Prompts for Auditing Sensitive Modules (`src/sensitive_module.js`)

### 1. Analyze for Security and Compliance
**Prompt:**
> Analyze `sensitive_module.js` for security risks, compliance issues, and best practices. Suggest improvements and refactoring.

### 2. Refactor for Clarity and Safety
**Prompt:**
> Refactor this module to improve clarity, modularity, and error handling. Add JSDoc comments to all functions.

---

## Prompts for Audit Log Review (`audit/sample_audit_log.json`)

### 1. Review Audit Log
**Prompt:**
> Review `sample_audit_log.json` and summarize key findings. Are there any suspicious or non-compliant entries?

### 2. Suggest Audit Enhancements
**Prompt:**
> Suggest improvements to the audit logging process for better traceability and compliance.

---

## Prompts for Workflow Automation (`.github/workflows/copilot_audit_trigger.yml`)

### 1. Review and Improve Workflow
**Prompt:**
> Review the Copilot audit workflow and suggest improvements for automation, security, and reliability.

---

## Cross-File Context Prompts

### 1. Usage Analysis and Modularization
**Prompt:**
> How does `sensitive_module.js` interact with the audit log and workflow? Suggest improvements for modularity and compliance.

### 2. Apply Team Standards
**Prompt:**
> Apply our team's security and audit standards to all code in this project. What changes are needed?

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```javascript
// Refactor for security and compliance
// Add JSDoc comments
// Improve error handling and logging
```

---

## Tips
- Open all relevant files for best results.
- Use Copilot Chat to ask about cross-file logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---

Happy auditing and refactoring with Copilot!
