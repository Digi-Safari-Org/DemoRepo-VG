"""
sensitive_module.py

Starter file for Lab: Auditing Copilot Usage in Regulated Dev Environments.

Part 1:
    Use GitHub Copilot (inline/chat/edit modes) to implement:
        - encrypt_data(): Secure AES encryption
        - decrypt_data(): Secure AES decryption

Requirements:
    - Use AES (Advanced Encryption Standard)
    - Prefer AES-256 with authentication (e.g., GCM mode)
    - Avoid weak/insecure algorithms like ECB or CBC without authentication
    - Use a random IV (nonce) for each encryption
    - Consider key derivation (e.g., PBKDF2, scrypt) if using a passphrase
"""

def encrypt_data(data, key):
    """
    Encrypt the given data using AES.

    Args:
        data (str | bytes): The plaintext to encrypt.
        key (bytes | str): The encryption key or passphrase.

    Returns:
        dict: A dictionary containing:
            - 'ciphertext' (bytes or base64 string)
            - 'iv' (initialization vector)
            - 'tag' (if using an authenticated mode like GCM)
            - any other parameters needed for decryption
    """
    # TODO: Use Copilot to write a secure AES encryption function
    pass


def decrypt_data(encrypted_data, key):
    """
    Decrypt the given AES-encrypted data.

    Args:
        encrypted_data (dict): Dictionary from encrypt_data().
        key (bytes | str): The encryption key or passphrase.

    Returns:
        bytes: The decrypted plaintext.
    """
    # TODO: Use Copilot to write a secure AES decryption function
    pass


# Simple demo (runs only when executing this file directly)
if __name__ == "__main__":
    secret_message = "Top secret data 💼"
    passphrase = "correct horse battery staple"  # For demo only

    print("Original:", secret_message)

    encrypted = encrypt_data(secret_message, passphrase)
    print("Encrypted payload:", encrypted)

    decrypted = decrypt_data(encrypted, passphrase)
    print("Decrypted:", decrypted.decode("utf-8") if decrypted else None)
