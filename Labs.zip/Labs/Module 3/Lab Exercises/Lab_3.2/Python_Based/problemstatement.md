# Lab: Auditing Copilot Usage in Regulated Dev Environments

## Objective
In this lab, you'll simulate how Copilot is used in a high-security module and how a compliance officer can audit its interactions using GitHub Enterprise Audit Logs.

## Scenario
You've written code in a sensitive file using Copilot. Now, your role shifts to that of a security auditor. You’ll examine the audit logs to track what Copilot generated, who accepted/rejected suggestions, and whether secure practices were followed.

---

## Part 1: Use Copilot in Sensitive Code

1. Open `src/sensitive_module.py`.
2. Use Copilot (inline/chat/edit) to write:
   - An `encrypt_data()` function using AES.
   - A `decrypt_data()` function.
3. Commit your changes.

---

## Part 2: Simulate Copilot Audit Log Review

1. Open `audit/sample_audit_log.json`.
2. Pretend this came from GitHub Enterprise Audit Log.
3. As a compliance reviewer, analyze:
   - Who used Copilot?
   - What suggestions were accepted/rejected?
   - Was a weak encryption method suggested and rejected?

---

## Optional: Create a Copilot-assisted Issue

If you find that a weak encryption method was suggested and accidentally accepted:
- Use Copilot Chat to help you write a structured GitHub Issue titled: `Potential Weak Encryption in sensitive_module.py`.

---

## Outcomes

- Understand Copilot usage traceability in enterprise audits.
- Simulate secure coding practices with compliance in mind.
