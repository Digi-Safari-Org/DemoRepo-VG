# 💡 Prompt Engineering for Lab: Auditing Copilot Usage

## While writing code (in `sensitive_module.py`)
> "Write a secure AES encryption function in Python."
> "Implement decryption that complements the AES encryption above."

## While reviewing audit logs
> "Summarize what Copilot suggestions were accepted by dev_alice."
> "Was base64 suggested as an encryption method?"

## For GitHub Issue (if weak method found)
> "Write a GitHub issue titled 'Potential Weak Encryption in sensitive_module.py' describing that base64 was used instead of AES."

---

## Compliance Investigation Prompts (Copilot Chat)

> "Analyze if any Copilot suggestions in the audit log use insecure algorithms."
> "Which files had Copilot suggestions accepted in the last 24 hours?"
