# Lab 4.2 – Cross-Framework Consistency & PR-based Test Review

## Lab Objective
In this lab, you will:
- Generate test cases in one framework (PyTest or Jest) and **convert them** into the other.
- Use **GitHub Copilot Enterprise Knowledge Bases (KB)** to ensure consistent structure, naming, and assertions.
- Review Copilot-generated test code via **pull requests (PRs)** and apply team standards.
- Simulate **cross-team collaboration** in a mixed-technology codebase.

---

## Scenario
Your enterprise software supports both **Python** and **JavaScript** services that perform similar logic.  
Currently, tests exist only for one framework in each service — and they are inconsistent in style and structure.

Your task is to:
1. Use **Copilot Enterprise** to convert the Python test into an equivalent JavaScript test, and vice versa.
2. Ensure both follow **KB-defined patterns** for naming, assertions, and setup.
3. Submit your changes as a PR and use Copilot Chat in PR review mode to catch style or coverage issues.

---

## Prerequisites
- **GitHub Copilot Enterprise** connected to your IDE.
- **Enterprise KB** containing test templates for PyTest and Jest.
- Python ≥ 3.9 installed with `pytest`.
- Node.js ≥ 18 installed with `jest`.
- Repo cloned locally with **Enterprise indexing** enabled.

---

## Starter Files
The repository is organized as:
```
Lab 4.2/
│
├── python_app/Starter Code/
│   ├── app/
│   │   ├── string_utils.py
│   │   └── order_service.py
│   ├── tests/
│   │   └── test_string_utils.py   # Partially complete
│   └── requirements.txt
│
├── js_app/Starter Code/
│   ├── src/
│   │   ├── stringUtils.js
│   │   └── orderService.js
│   ├── tests/
│   │   └── stringUtils.test.js    # Partially complete
│   └── package.json
│
└── README.md
```

---

## Lab Steps

### **Step 1 – Review Existing Tests**
1. Open `python_app/tests/test_string_utils.py`.
2. Identify covered functions and note which ones are missing.
3. Open `js_app/tests/stringUtils.test.js` and do the same.

---

### **Step 2 – Cross-Framework Test Conversion**
1. Pick a function tested in Python but missing in JavaScript.
2. Use Copilot Chat:
   ```
   Convert this PyTest test into an equivalent Jest test following @kb test_template_jest.
   ```
3. Repeat for JavaScript → Python conversion using:
   ```
   Convert this Jest test into an equivalent PyTest test following @kb test_template_pytest.
   ```

---

### **Step 3 – Apply KB Standards**
1. For both converted tests, ensure:
   - Naming follows KB conventions.
   - Assertions match KB guidelines.
   - Setup/teardown is consistent with KB examples.
2. If differences are found, prompt Copilot:
   ```
   Update these tests to fully match @kb enterprise_test_standards.
   ```

---

### **Step 4 – Submit a Pull Request**
1. Commit your new and converted tests.
2. Push to a feature branch and open a PR.

---

### **Step 5 – PR Review with Copilot**
1. In the PR view, use Copilot Chat:
   ```
   Review all new and modified test files for KB compliance, naming consistency, and complete coverage.
   ```
2. Apply any suggested changes.
3. Confirm that **audit trails** show the review history.

---

## Enterprise Copilot Tips
- Always reference KB templates directly in prompts (`@kb test_template_pytest` or `@kb test_template_jest`).
- Use **multi-file selection** when converting related tests.
- In PR review mode, ask Copilot to **highlight coverage gaps**.

---

## Expected Outcomes
- Equivalent test coverage for the same logic in both Python and JavaScript.
- Consistent naming, structure, and assertions across frameworks.
- PR-reviewed and KB-compliant tests with audit logs for accountability.

---

## Review Checklist
- [ ] All functions have equivalent tests in both frameworks.
- [ ] Test structure and naming match KB standards.
- [ ] Assertions follow KB guidelines.
- [ ] All changes were PR-reviewed with Copilot and documented in audit logs.

---


