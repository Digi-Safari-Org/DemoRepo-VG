const { toUppercase, reverseString } = require("../src/stringUtils");

// Example completed test (to be used for conversion to PyTest)
test("toUppercase converts lowercase to uppercase", () => {
    expect(toUppercase("hello")).toBe("HELLO");
});

// TODO: Add a test for toUppercase() with non-string input (should throw Error)
// TODO: Add a test for reverseString() basic case
// TODO: Add a test for reverseString() with non-string input
// TODO: Follow KB naming conventions for all tests
