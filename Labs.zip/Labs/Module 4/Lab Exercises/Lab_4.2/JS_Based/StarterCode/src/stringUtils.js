function toUppercase(text) {
    if (typeof text !== "string") {
        throw new Error("Input must be a string");
    }
    return text.toUpperCase();
}

function reverseString(text) {
    if (typeof text !== "string") {
        throw new Error("Input must be a string");
    }
    return text.split("").reverse().join("");
}

module.exports = { toUppercase, reverseString };
