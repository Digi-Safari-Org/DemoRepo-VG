function calculateTotal(items) {
    return items.reduce((total, item) => total + item.price * item.quantity, 0);
}

function applyDiscount(total, discountPercent) {
    if (discountPercent < 0 || discountPercent > 100) {
        throw new Error("Discount percent must be between 0 and 100");
    }
    return total * (1 - discountPercent / 100);
}

module.exports = { calculateTotal, applyDiscount };
