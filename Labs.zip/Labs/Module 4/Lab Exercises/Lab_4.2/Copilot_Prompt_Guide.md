# Copilot Prompt Guide for Lab 4.2: Cross-Framework Test Standards for JS and Python Projects

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the testing and standardization tasks in Lab 4.2. Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity for both JavaScript and Python projects.

---

## Prompts for JavaScript Project (`JS Based/Starter Code/`)

### 1. Analyze and Suggest Improvements
**Prompt:**
> Analyze `orderService.js` and `stringUtils.js` for test coverage, naming conventions, and modularity. Suggest improvements based on cross-framework test standards.

### 2. Refactor and Add Tests
**Prompt:**
> Refactor functions for clarity and reliability. Add or expand tests in `stringUtils.test.js` to cover edge cases and error scenarios.

### 3. Apply Cross-Framework Standards
**Prompt:**
> Apply the standards from `cross_framework_test_standards.md` to the JS codebase. What changes are needed?

---

## Prompts for Python Project (`Python Based/Starter Code/`)

### 1. Review and Refactor for Standards
**Prompt:**
> Review `order_service.py` and `string_utils.py` for compliance with cross-framework test standards. Refactor code for clarity, modularity, and maintainability.

### 2. Add Type Hints and Docstrings
**Prompt:**
> Add type hints and Google-style docstrings to all functions in `order_service.py` and `string_utils.py`.

### 3. Expand and Improve Tests
**Prompt:**
> Review and expand tests in `test_string_utils.py` to cover edge cases, error handling, and ensure robust coverage.

### 4. Use Shared Standards
**Prompt:**
> Reference `cross_framework_test_standards.md` for best practices. What improvements can be made to the Python code and tests?

---

## Cross-Project Context Prompts

### 1. Compare Testing Approaches
**Prompt:**
> Compare the testing approaches in JS and Python projects. How can cross-framework standards be applied consistently across both?

### 2. Modularization and Reusability
**Prompt:**
> Suggest improvements for modularity and reusability in both JS and Python codebases based on cross-framework standards.

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```python
# Refactor for clarity and modularity
# Add type hints and docstrings
# Expand tests for edge cases
# Apply cross-framework test standards
```
```javascript
// Refactor for reliability and clarity
// Add/expand tests for edge cases
// Apply cross-framework test standards
```

---

## Tips
- Open all relevant files for best results.
- Use Copilot Chat to ask about cross-file and cross-project logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---
