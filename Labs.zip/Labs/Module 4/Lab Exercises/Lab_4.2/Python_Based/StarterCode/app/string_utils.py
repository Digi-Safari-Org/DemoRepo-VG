def to_uppercase(text):
    """Convert a string to uppercase."""
    if not isinstance(text, str):
        raise ValueError("Input must be a string")
    return text.upper()

def reverse_string(text):
    """Reverse the given string."""
    if not isinstance(text, str):
        raise ValueError("Input must be a string")
    return text[::-1]
