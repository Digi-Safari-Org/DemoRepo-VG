def calculate_total(items):
    """
    Calculate total price from a list of items.
    Each item is a dict with 'price' and 'quantity'.
    """
    return sum(item["price"] * item["quantity"] for item in items)

def apply_discount(total, discount_percent):
    """
    Apply discount to a total price.
    discount_percent should be between 0 and 100.
    """
    if not (0 <= discount_percent <= 100):
        raise ValueError("Discount percent must be between 0 and 100")
    return total * (1 - discount_percent / 100)
