import pytest
from app.string_utils import to_uppercase, reverse_string

def test_to_uppercase_valid():
    assert to_uppercase("hello") == "HELLO"

# ❌ Missing: tests for reverse_string
# ❌ Missing: tests for non-string input (error handling)
