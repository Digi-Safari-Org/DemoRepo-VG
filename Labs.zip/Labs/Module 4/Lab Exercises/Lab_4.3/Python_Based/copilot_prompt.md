# Copilot Prompt and Lab Steps for Module 4.3 

## Copilot Prompt
```
# Part A: Order Service Function Testing
# 1. Write unit tests for calculate_discount, calculate_tax, and final_price in order_calculator.py using PyTest parameterization.
# 2. Write integration tests for discount + tax workflows.
# 3. Add a regression test for final_price(100, 100, 10) expecting 0.0 (historically returned 10.0).
# 4. Move test parameters into test_data.py and import in all test files.
# 5. Follow naming conventions, Google-style docstrings, and Arrange-Act-Assert in all tests.
# 6. Produce a PR description summarizing test coverage, frameworks, parameterized cases, regression, and a reviewer checklist.

# Part B: API Endpoint Testing
# 1. Write PyTest + requests and unittest + requests tests for the /calculate endpoint in app.py.
# 2. Parameterize tests for multiple payloads, sourced from shared test_data.py.
# 3. Create api_helpers.py with a post_calculate(a, b) helper using requests.post and returning the parsed response.
# 4. Use Google-style docstrings, Arrange-Act-Assert, and proper test naming in all tests.
# 5. Generate an audit summary listing framework coverage, parameterized cases, helper reuse, and regression coverage.
```

---

## Detailed Steps to Complete the Lab

### Part A — Function-Level Testing (Order_service/order_calculator.py)
1. Open `Order_service/order_calculator.py` and review the functions: calculate_discount, calculate_tax, final_price.
2. In `Order_service/test_order_calculator_pytest.py` and `test_order_calculator_unittest.py`, write unit and integration tests for each function using PyTest parameterization and unittest.
3. Add a regression test for final_price(100, 100, 10) expecting 0.0.
4. Move test parameters into `test_data.py` and import in all test files.
5. Ensure all test files and helpers use Google-style docstrings and Arrange-Act-Assert structure.
6. Write a PR description (Order_service/PR_Descripton_partA.md) summarizing test coverage, frameworks, parameterized cases, regression, and a reviewer checklist.

### Part B — API Endpoint Testing (Part_B/api-service/app.py)
1. Open `Part_B/api-service/app.py` and review the /calculate endpoint.
2. In `Part_B/api_helpers.py`, implement post_calculate(a, b) using requests.post.
3. In `Part_B/test_calculate_pytest.py` and `test_calculate_unittest.py`, write PyTest and unittest tests for /calculate, parameterized using test_data_api.py.
4. Ensure all test files and helpers use Google-style docstrings, Arrange-Act-Assert, and proper test naming.
5. Write an audit summary listing framework coverage, parameterized cases, helper reuse, and regression coverage.
