# Module 4.3: Automated Testing with Copilot 

### Objective 
- Generate unit, integration, and regression tests in JavaScript.

- Use parameterized test generation.

- Eliminate redundant test creation across frameworks by reusing shared test data / helpers.

- Perform cross-framework test integration (Jest + Mocha).

- Use a Knowledge Base (naming, docstrings/JSDoc, ARRANGE-ACT-ASSERT) for consistent tests.

- Review generated test code via audit trails and Pull Requests.

Part A — Function-Level Testing
Scenario

You are working in the order_service/ module of an e-commerce platform. The orderCalculator.js file contains three small functions:

```js
// order_service/orderCalculator.js

function calculateDiscount(price, discountPercentage) {
  return price - (price * discountPercentage / 100);
}

function calculateTax(price, taxRate) {
  return price + (price * taxRate / 100);
}

function finalPrice(price, discountPercentage, taxRate) {
  const discounted = calculateDiscount(price, discountPercentage);
  return calculateTax(discounted, taxRate);
}

module.exports = { calculateDiscount, calculateTax, finalPrice };
```
Tasks

1. Unit Tests (function-level)

    - Create unit tests for:

       - calculateDiscount

       - calculateTax

       - finalPrice

   - Use Jest with parameterized test cases (Jest test.each or similar).

2. Integration Tests (workflow-level)

   - Create Mocha (with Chai) integration tests that verify discount + tax workflows using the exported functions together.

3. Regression Tests

   - Add a regression test that verifies the historical bug is fixed:

   - finalPrice(100, 100, 10) → Expected: 0.0 (previously returned 10.0).

4. Avoid Redundancy

   - Create a shared test_data.js that exports test cases and parameter arrays.

   - Both Jest and Mocha tests should import test_data.js to reuse the same data.

5. Consistency via Knowledge Base

   - Follow naming conventions (tests start with test where applicable).

   - Use Google-style JSDoc for each test file and helper function.

   - Use Arrange-Act-Assert comments/structure in every test.

6. Pull Request Simulation

   - Produce a PR description summarizing test coverage, frameworks used, parameterized cases, and the regression case.

   - Include a reviewer checklist (unit tests, integration tests, test data reuse, docstrings present).

Part B — API Endpoint Testing

### Scenario

You have an Express API /calculate endpoint in app.js:
```js
// api_service/app.js
const express = require('express');
const app = express();
app.use(express.json());

app.post('/calculate', (req, res) => {
  const { a, b } = req.body;
  const total = a + b;
  res.json({ result: total });
});

if (require.main === module) {
  app.listen(3000, () => console.log('Server running on port 3000'));
}

module.exports = app;

```

### Tasks

1. Integration Tests (HTTP-level)

      - Create Jest + supertest tests for /calculate.

      - Create Mocha + supertest tests for /calculate.

   - Both frameworks should run the server in test mode (import app and use supertest(app)).

2. Parameterized Cases

   - Parameterize tests for multiple payloads, e.g.:

     - { a: 1, b: 2 } -> 3

     - { a: 0, b: 0 } -> 0

     - { a: -5, b: 10 } -> 5

   - Source these payloads from the shared test_data.js.

3. Avoid Redundancy

   - Create api_helpers.js with a postCalculate(a, b) helper that uses supertest(app).post('/calculate')... and returns the parsed response.

   - Both Jest and Mocha tests should import and use api_helpers.js.
   - Test the endpoints via Postman/Bruno.

4. Consistency via Knowledge Base

   - Test function names must start with test or use descriptive it blocks.
    
   - Use Google-style JSDoc comments in test files and helpers.

   - Apply Arrange-Act-Assert structure and short lived server lifecycle management (start/close if needed).

5. Pull Request Simulation

   - Generate an audit summary listing:

     - Framework coverage (Jest, Mocha)

     - Parameterized cases included

     - Helper reuse (test_data.js, api_helpers.js)

     - Regression coverage