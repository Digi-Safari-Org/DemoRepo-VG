# Copilot Prompt and Lab Steps for Module 4.3

## Copilot Prompt
```
// Part A: Order Service Function Testing
// 1. Write unit tests for calculateDiscount, calculateTax, and finalPrice in orderCalculator.js using Jest with parameterized test.each.
// 2. Write Mocha (with Chai) integration tests for discount + tax workflows using the exported functions together.
// 3. Add a regression test for finalPrice(100, 100, 10) expecting 0.0 (historically returned 10.0).
// 4. Create a shared test_data.js for test cases and parameter arrays, imported by both Jest and Mocha tests.
// 5. Follow naming conventions, Google-style JSDoc, and Arrange-Act-Assert in all tests.
// 6. Produce a PR description summarizing test coverage, frameworks, parameterized cases, regression, and a reviewer checklist.

// Part B: API Endpoint Testing
// 1. Write Jest + supertest and Mocha + supertest tests for the /calculate endpoint in api_service/app.js.
// 2. Parameterize tests for multiple payloads (e.g., { a: 1, b: 2 } -> 3) sourced from shared test_data.js.
// 3. Create api_helpers.js with a postCalculate(a, b) helper using supertest(app).post('/calculate') and returning the parsed response.
// 4. Use Google-style JSDoc, Arrange-Act-Assert, and short-lived server lifecycle management in all tests.
// 5. Generate an audit summary listing framework coverage, parameterized cases, helper reuse, and regression coverage.
```

---

## Detailed Steps to Complete the Lab

### Part A — Function-Level Testing (order_Service/orderCalculator.js)
1. Open `order_Service/orderCalculator.js` and review the three functions: calculateDiscount, calculateTax, finalPrice.
2. In `order_Service/tests/jest/orderCalculator.test.js`, write unit tests for each function using Jest's parameterized test.each.
3. In `order_Service/tests/mocha/order_workflow.spec.js`, write Mocha (with Chai) integration tests for workflows combining discount and tax.
4. Add a regression test for finalPrice(100, 100, 10) expecting 0.0.
5. Create `order_Service/test_data.js` to export test cases and parameter arrays for reuse in both Jest and Mocha tests.
6. Ensure all test files and helpers use Google-style JSDoc and Arrange-Act-Assert structure.
7. Write a PR description (order_Service/PR_Description.md) summarizing test coverage, frameworks, parameterized cases, regression, and a reviewer checklist.

### Part B — API Endpoint Testing (Part_B/api_service/app.js)
1. Open `Part_B/api_service/app.js` and review the /calculate endpoint.
2. In `Part_B/api_helpers.js`, implement postCalculate(a, b) using supertest(app).post('/calculate').
3. In `Part_B/tests/jest/api/calculate.test.js`, write Jest + supertest tests for /calculate, parameterized using test_data.js.
4. In `Part_B/tests/mocha/api/calculate.spec.js`, write Mocha + supertest tests for /calculate, parameterized using test_data.js.
5. Ensure all test files and helpers use Google-style JSDoc, Arrange-Act-Assert, and manage server lifecycle as needed.
6. Write an audit summary listing framework coverage, parameterized cases, helper reuse, and regression coverage.
