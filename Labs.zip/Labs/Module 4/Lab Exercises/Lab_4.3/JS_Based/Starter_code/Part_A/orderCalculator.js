function calculateDiscount(price, discountPercentage) {
  return price - (price * discountPercentage / 100);
}

function calculateTax(price, taxRate) {
  return price + (price * taxRate / 100);
}

function finalPrice(price, discountPercentage, taxRate) {
  const discounted = calculateDiscount(price, discountPercentage);
  return calculateTax(discounted, taxRate);
}

module.exports = { calculateDiscount, calculateTax, finalPrice };