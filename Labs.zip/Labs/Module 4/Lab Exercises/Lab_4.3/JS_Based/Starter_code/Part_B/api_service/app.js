const express = require('express');
const app = express();
app.use(express.json());

app.post('/calculate', (req, res) => {
  const { a, b } = req.body;
  const total = a + b;
  res.json({ result: total });
});

if (require.main === module) {
  app.listen(3000, () => console.log('Server running on port 3000'));
}

module.exports = app;
