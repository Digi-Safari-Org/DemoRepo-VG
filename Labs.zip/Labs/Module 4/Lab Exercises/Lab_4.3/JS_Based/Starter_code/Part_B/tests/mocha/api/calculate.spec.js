// Create a Mocha + Chai integration test suite
