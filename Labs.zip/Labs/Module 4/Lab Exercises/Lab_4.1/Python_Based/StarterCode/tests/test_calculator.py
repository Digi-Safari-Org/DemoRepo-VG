"""
Tests for calculator.py

👉 NOTE: Follow Knowledge Base (KB) guidelines for:
    - Test naming conventions
    - Parameterized test patterns
    - Setup/teardown structure
    - Ensuring consistency across teams
"""

import pytest
from calculator import Calculator


@pytest.fixture
def calc():
    """Fixture to provide a Calculator instance."""
    return Calculator()


# -------------------
# Unit Tests
# -------------------

def test_add_basic(calc):
    """TODO: Write unit test for addition (refer to KB structure)."""
    pass


def test_subtract_basic(calc):
    """TODO: Write unit test for subtraction (refer to KB structure)."""
    pass


def test_multiply_basic(calc):
    """TODO: Write unit test for multiplication (refer to KB structure)."""
    pass


def test_divide_by_nonzero(calc):
    """TODO: Write test for valid division (refer to KB structure)."""
    pass


def test_divide_by_zero(calc):
    """TODO: Write test to assert ZeroDivisionError."""
    pass


def test_power(calc):
    """TODO: Write parameterized test for positive/negative exponents using KB patterns."""
    pass


def test_factorial_non_negative(calc):
    """TODO: Write regression test for factorial with multiple inputs (refer to KB)."""
    pass


def test_factorial_negative(calc):
    """TODO: Ensure ValueError is raised for negative input."""
    pass


# -------------------
# Integration Example
# -------------------

def test_combined_operations(calc):
    """
    TODO: Integration test.
    Example: (3 + 2) * factorial(3) → 5 * 6 = 30
    Structure should align with KB cross-framework examples.
    """
    pass
