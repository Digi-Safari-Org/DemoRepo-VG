"""
Data Processor Module (Starter)

Your tasks:
1. Implement functions to load, clean, transform, and summarize CSV data.
2. Use Copilot to:
   - Add parameterization for flexibility.
   - Improve error handling and logging.
   - Insert proper docstrings and typing hints.
3. Prepare this codebase for generating **unit, integration, and regression tests**.

HINT: 
This module will later be tested across multiple frameworks (PyTest, unittest/xUnit, Jest via API mocks).
"""

import csv
import logging
import statistics
from typing import List, Dict, Any

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")


def load_data(file_path: str, delimiter: str = ",") -> List[Dict[str, Any]]:
    """
    Loads CSV data from a file.

    Args:
        file_path (str): Path to the CSV file.
        delimiter (str): CSV delimiter (default: ',').

    Returns:
        List[Dict[str, Any]]: List of rows as dictionaries.

    TODO for developers:
    - Validate header existence (raise ValueError if missing).
    - Add parameter for encoding (utf-8, latin-1, etc.).
    - Use Copilot to generate regression tests for invalid inputs.
    """
    rows = []
    with open(file_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        if not reader.fieldnames:
            raise ValueError("CSV file is missing headers.")
        for row in reader:
            rows.append(row)
    logging.info(f"Loaded {len(rows)} rows from {file_path}")
    return rows


def clean_data(rows: List[Dict[str, Any]], numeric_columns: List[str] = None) -> List[Dict[str, Any]]:
    """
    Cleans up the data.

    Args:
        rows (List[Dict[str, Any]]): Raw rows.
        numeric_columns (List[str]): Columns that should be numeric.

    Returns:
        List[Dict[str, Any]]: Cleaned rows.

    TODO for developers:
    - Strip spaces from all string values.
    - Convert numeric_columns to floats, invalid -> None.
    - Write parameterized test cases for various edge cases:
      * Missing values
      * Extra whitespace
      * Invalid numerics
    """
    cleaned = []
    for r in rows:
        row_copy = {}
        for k, v in r.items():
            if v is None:
                row_copy[k] = None
                continue
            value = v.strip()
            if numeric_columns and k in numeric_columns:
                try:
                    row_copy[k] = float(value)
                except ValueError:
                    row_copy[k] = None
            else:
                row_copy[k] = value
        cleaned.append(row_copy)
    logging.info(f"Cleaned {len(cleaned)} rows")
    return cleaned


def summarize_data(rows: List[Dict[str, Any]], column: str) -> Dict[str, float]:
    """
    Generates summary statistics for a given column.

    Args:
        rows (List[Dict[str, Any]]): Cleaned rows.
        column (str): Column to summarize.

    Returns:
        Dict[str, float]: Summary containing mean, min, max.

    TODO for developers:
    - Handle case where column has no valid numeric values.
    - Write integration test combining load + clean + summarize.
    - Use regression tests to validate against known dataset outputs.
    """
    values = [r[column] for r in rows if isinstance(r[column], (int, float))]
    if not values:
        raise ValueError(f"No valid numeric values found in column '{column}'")
    return {
        "mean": statistics.mean(values),
        "min": min(values),
        "max": max(values),
    }
