"""
Calculator module with basic arithmetic operations
and some edge cases for learners to test.
"""

class Calculator:
    def add(self, a, b):
        """Return the sum of a and b."""
        return a + b

    def subtract(self, a, b):
        """Return the result of a - b."""
        return a - b

    def multiply(self, a, b):
        """Return the product of a and b."""
        return a * b

    def divide(self, a, b):
        """
        Return the result of a / b.
        Raises ZeroDivisionError if b == 0.
        """
        if b == 0:
            raise ZeroDivisionError("Cannot divide by zero.")
        return a / b

    def power(self, base, exponent):
        """
        Return base raised to exponent.
        Handles negative exponents as floats.
        """
        return base ** exponent

    def factorial(self, n):
        """
        Return factorial of n.
        Raises ValueError if n < 0.
        """
        if n < 0:
            raise ValueError("Factorial not defined for negative numbers.")
        if n == 0:
            return 1
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result
