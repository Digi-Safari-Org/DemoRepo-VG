# Lab 4.1 – Enterprise-Scale Test Generation & Optimization

## Lab Objective
In this lab, you will:
- Generate **unit, integration, and regression test cases** in a single workflow.
- Use **parameterized tests** to handle multiple input-output scenarios.
- Eliminate redundant tests across teams using **GitHub Copilot Enterprise Knowledge Base (KB)**.
- Apply **Enterprise context indexing** to enhance cross-file test generation.

---

## Scenario
You are part of the QA automation team at a large enterprise managing both **Python** and **JavaScript** services.  
The existing codebase has partial test coverage, but:
1. Several core functions lack unit tests.
2. Integration workflows are missing end-to-end validation.
3. Known bugs are resurfacing due to missing regression tests.
4. Multiple teams have introduced **duplicate tests** for the same functionality.
5. Test logic is repetitive and not parameterized.

Your task is to **modernize the test suite** using **GitHub Copilot Enterprise**, ensuring:
- Consistent structure
- No redundancy
- Future maintainability

---

## Prerequisites
- **GitHub Copilot Enterprise** enabled and connected to VS Code or JetBrains IDE.
- **Enterprise Knowledge Base (KB)** with:
  - Test patterns & templates
  - Naming conventions
- Python ≥ 3.9 installed with `pytest`
- Node.js ≥ 18 installed with `jest`
- Repo cloned locally with **Enterprise indexing** enabled.

---

## Starter Files
The repository is organized as:
```
Lab 4.1/
│
├── python_app/Starter Code/
│   ├── app/
│   │   ├── calculator.py
│   │   └── data_processor.py
│   ├── tests/
│   │   ├── test_calculator.py
│   │   └── test_data_processor.py
│   └── requirements.txt
│
├── js_app/Starter Code/
│   ├── src/
│   │   ├── mathUtils.js
│   │   └── apiClient.js
│   ├── tests/
│   │   ├── mathUtils.test.js
│   │   └── apiClient.test.js
│   └── package.json
│
└── README.md
```

---

## 📝 Lab Steps

### **Step 1 – Generate Unit Tests**
1. Open `python_app/app/calculator.py`.
2. Use Copilot Chat:
   ```
   /tests Create PyTest unit tests for all functions in calculator.py following KB patterns. Include edge cases.
   ```
3. Repeat for `js_app/src/mathUtils.js`:
   ```
   /tests Create Jest unit tests for all functions in mathUtils.js following KB templates.
   ```
4. Save generated tests in their respective `tests/` folders.

---

### **Step 2 – Create Integration Tests**
1. For Python:
   - Open `python_app/app/data_processor.py`.
   - In Copilot Chat:
     ```
     /tests Generate an integration test for loading and filtering data using pytest. Cover success and failure cases.
     ```
2. For JavaScript:
   - Open `js_app/src/apiClient.js`.
   - In Copilot Chat:
     ```
     /tests Create a Jest integration test for fetchData() and processData() together. Include success and error scenarios.
     ```

---

### **Step 3 – Add Regression Tests**
1. Document known bugs in `README.md` or a separate file.
2. For each bug, prompt Copilot:
   ```
   /tests Create regression tests for the listed bugs using pytest or jest as appropriate.
   ```

---

### **Step 4 – Parameterize Tests**
1. Identify repetitive test logic in both Python and JavaScript test files.
2. For Python:
   ```
   Refactor these repetitive pytest cases into parameterized tests using @pytest.mark.parametrize.
   ```
3. For JavaScript:
   ```
   Refactor these repetitive Jest cases into test.each format.
   ```

---

### **Step 5 – Remove Redundant Tests**
1. Use Copilot Enterprise KB Search:
   ```
   @kb search "duplicate tests across calculator and mathUtils modules"
   ```
2. Consolidate duplicate logic into a single test per case.
3. Remove redundant files.

---

## 💡 Enterprise Copilot Tips
- Use `@kb` references in prompts for consistent style:
  ```
  Create PyTest tests for calculator.py using @kb enterprise_test_template
  ```
- Multi-file selection improves context for integration tests.
- Always review generated tests via PR before merging.

---

## ✅ Expected Outcomes
- Full unit test coverage for Python and JavaScript modules.
- Integration tests validate real workflows.
- Regression tests prevent recurrence of known bugs.
- Parameterized tests reduce repetition.
- No redundant tests in the suite.
- All tests match KB conventions.

---

## 🔍 Review Checklist
- [ ] Unit tests cover all functions.
- [ ] Integration tests simulate workflows.
- [ ] Regression tests match bug reports.
- [ ] Parameterized tests replace repetition.
- [ ] Redundancy eliminated.
- [ ] Naming and structure match KB.
---

## The goal is not just to “write tests,” but to:
- Think like an enterprise QA engineer
- Use AI-assisted workflows to improve coverage and maintainability
- Leverage Copilot Enterprise features beyond standard Copilot


