# Copilot Prompt Guide – Lab 4.1: Enterprise-Scale Test Generation & Optimization

This guide provides practical **Copilot Chat** and inline comment prompts to help developers complete Lab 4.1 efficiently using **GitHub Copilot Enterprise** and the **enterprise test standards KB**.

---

## 🔹 Python Project Prompts (`python_app/`)

### 1. Unit Tests – `calculator.py`
```
/tests Create PyTest unit tests for all functions in calculator.py following @kb enterprise_test_template. Include edge cases and error handling.
```

### 2. Integration Tests – `data_processor.py`
```
/tests Generate an integration test for load_data() and filter_data() together using pytest. Cover success and failure cases.
```

### 3. Regression Tests (Python)
```
/tests Create regression tests for known bugs documented in README.md using pytest. Follow @kb enterprise_test_standards.
```

### 4. Parameterization (Python)
```
Refactor repetitive tests in test_calculator.py into parameterized tests using @pytest.mark.parametrize following KB guidelines.
```

---

## 🔹 JavaScript Project Prompts (`js_app/`)

### 1. Unit Tests – `mathUtils.js`
```
/tests Create Jest unit tests for add, subtract, multiply, and divide in mathUtils.js following @kb test_template_jest. Include edge cases and division by zero regression case.
```

### 2. Integration Tests – `apiClient.js`
```
/tests Create a Jest integration test combining fetchData() and processData(). Cover success (valid JSON), error (network failure), and threshold edge cases.
```

### 3. Regression Tests (JS)
```
/tests Create Jest regression tests for any reported bugs listed in README.md. Ensure KB naming conventions are applied.
```

### 4. Parameterization (JS)
```
Refactor repetitive Jest test cases into test.each format following @kb enterprise_test_standards.
```

---

## 🔹 Cross-Project Prompts

### 1. Detect Redundant Tests
```
@kb search "duplicate tests across calculator and mathUtils modules"
```

### 2. Compare Consistency
```
Compare Python (PyTest) and JS (Jest) test suites. Suggest improvements for consistent naming, structure, and assertions using enterprise KB.
```

---

## 🔹 Inline Comment Prompts

Add these as inline comments in test files to guide Copilot:
```python
# TODO: Expand test coverage for edge cases using enterprise KB
# TODO: Refactor into parameterized test with pytest.mark.parametrize
# TODO: Apply enterprise test standards (naming, assertions, fixtures)
```
```javascript
// TODO: Add regression test case based on known bug reports
// TODO: Convert repetitive tests into test.each parameterization
// TODO: Apply enterprise KB test_template_jest for structure
```

---

## ✅ Best Practices
- Always reference **@kb enterprise_test_standards** in prompts.  
- Use **multi-file selection** for integration tests.  
- Run **PR review with Copilot** before merging.  
- Document **regression tests** in README.md for traceability.  

---
