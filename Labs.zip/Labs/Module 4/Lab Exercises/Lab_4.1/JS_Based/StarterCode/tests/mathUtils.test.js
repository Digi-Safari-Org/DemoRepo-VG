const { fetchData, processData } = require("../src/apiClient");

// TODO: Mock fetch and test fetchData() for both success and failure
// TODO: Write integration test: fetchData() + processData() together
// TODO: Parameterize test cases for processData() with various thresholds
// TODO: Follow KB template for all tests

// Starter Test File for mathUtils.js
// TODOs guide Copilot to expand with enterprise test standards

const { add, subtract, multiply, divide } = require("../src/mathUtils");

describe("mathUtils Unit Tests", () => {
  // TODO: Add parameterized tests using test.each for add, subtract, multiply
  test("add should return correct sum", () => {
    expect(add(2, 3)).toBe(5);
  });

  test("subtract should return correct difference", () => {
    expect(subtract(5, 2)).toBe(3);
  });

  test("multiply should return correct product", () => {
    expect(multiply(4, 3)).toBe(12);
  });

  // Regression test for divide by zero
  test("divide should throw error when dividing by zero", () => {
    expect(() => divide(10, 0)).toThrow("Division by zero is not allowed");
  });

  // TODO: Add more edge case tests (negative numbers, floats, large values)
});
