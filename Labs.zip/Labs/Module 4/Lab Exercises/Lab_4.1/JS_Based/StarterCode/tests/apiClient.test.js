
const { fetchData, processData } = require("../src/apiClient");

describe("apiClient Integration Tests", () => {
  // Mock fetch for integration testing
  beforeAll(() => {
    global.fetch = jest.fn();
  });

  afterAll(() => {
    jest.restoreAllMocks();
  });

  test("fetchData should return parsed JSON on success", async () => {
    const mockData = [{ id: 1, value: 10 }];
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => mockData,
    });

    const result = await fetchData("http://fakeapi.com/data");
    expect(result).toEqual(mockData);
  });

  test("fetchData should throw error on network failure", async () => {
    global.fetch.mockResolvedValueOnce({ ok: false, status: 500 });

    await expect(fetchData("http://fakeapi.com/data")).rejects.toThrow(
      "API request failed with status 500"
    );
  });

  test("processData should filter items above threshold", () => {
    const data = [
      { name: "A", value: 10 },
      { name: "B", value: 5 },
    ];
    const result = processData(data, 6);
    expect(result).toEqual([{ name: "A", value: 10 }]);
  });

  // TODO: Add integration test combining fetchData() + processData()
  // TODO: Add parameterized tests for processData thresholds
  // TODO: Add regression test for previously reported bug (if documented)
});
