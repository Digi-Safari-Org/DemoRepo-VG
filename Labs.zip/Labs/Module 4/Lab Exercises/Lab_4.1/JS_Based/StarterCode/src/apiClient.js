async function fetchData(apiUrl) {
    const response = await fetch(apiUrl);
    if (!response.ok) {
        throw new Error("Network response was not ok");
    }
    return response.json();
}

function processData(data, threshold) {
    return data.filter(item => item.value > threshold);
}

module.exports = { fetchData, processData };
