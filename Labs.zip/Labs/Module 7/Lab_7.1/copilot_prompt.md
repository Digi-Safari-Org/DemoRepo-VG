# Copilot Prompt for Module 7: GitHub Copilot Enterprise Policy & Role-Based Access Simulation

## Copilot Prompt
You are acting as a GitHub Copilot Enterprise Admin for the fictional company InnovaWorks. Your tasks are to create and enforce Copilot policy configurations, implement role-based access, simulate license allocation, apply repository/content restrictions, generate telemetry logs, and document a formal role-change workflow. Follow the steps below to complete the capstone lab.

## Steps to Complete the Lab

1. **Define Copilot Policy Configuration**
   - Create `policy_config.yaml` specifying:
     - Allowed and blocked repositories for each role.
     - Content exclusions (e.g., `/private/`).
     - Global telemetry and prompt audit settings.

2. **Generate Role Access Matrix**
   - Create `role_access_matrix.json` defining:
     - Copilot enablement per role.
     - Allowed/blocked repositories and exclusions for each role.

3. **Simulate License Allocation**
   - Create `license_allocation.yaml` showing:
     - Number of Copilot seats allocated per role.
     - Remaining available seats (total 50).
     - Allocation priority: Org_Admin > Senior_Dev > Junior_Dev > External_Contractor.

4. **Simulate Telemetry Log Entries**
   - Create `telemetry_log_sample.md` with at least two entries:
     - One allowed prompt by a permitted role/repo.
     - One blocked prompt attempt by a restricted role/repo.

5. **Document Role Change Workflow**
   - Create `role_change_request.md` as a markdown form for requesting role upgrades/downgrades, including required approvals (only Org_Admin can approve).

---

**Use GitHub Copilot Enterprise to draft, validate, and refine all configuration, policy, and documentation files for clarity, compliance, and completeness.**
