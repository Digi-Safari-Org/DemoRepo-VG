# Copilot Prompt Guide for Lab 2.1: Refactoring and Standardization with Copilot Chat

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the refactoring and standardization tasks in Lab 2.1. Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity.

---

## Prompts for Python Files (`processor/`, `tests/`)

### 1. Analyze and Suggest Improvements
**Prompt:**
> Analyze `helpers.py` and `legacy_data.py` for naming, efficiency, and modularity. Suggest improvements based on our team standards in `KB/naming-standards.md`.

### 2. Refactor Legacy Functions
**Prompt:**
> Refactor legacy functions in `legacy_data.py` to follow our naming conventions and add type hints. Move reusable logic to `helpers.py` if appropriate.

### 3. Add Docstrings and Logging
**Prompt:**
> Add Google-style docstrings and logging to all functions for better maintainability and traceability.

### 4. Update and Expand Tests
**Prompt:**
> Review `test_legacy_data.py` and update tests to match refactored function signatures. Add new tests for edge cases and error handling.

---

## Prompts for JavaScript File (`webui/frontend.js`)

### 1. Refactor Legacy Patterns
**Prompt:**
> Refactor legacy code in `frontend.js` to use modern JavaScript patterns and update variable names for clarity.

### 2. Add Inline Documentation
**Prompt:**
> Add inline documentation and comments to explain key logic and improve maintainability.

---

## Cross-File Context Prompts

### 1. Usage Analysis and Modularization
**Prompt:**
> How are functions in `helpers.py` used in `legacy_data.py` and `test_legacy_data.py`? Suggest improvements for modularity and reusability.

### 2. Apply Team Standards
**Prompt:**
> Apply the standards from `KB/naming-standards.md` and `KB/refactor-template.md` to all code in this project. What changes are needed?

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```python
# Refactor for clarity and modularity
# Add type hints and docstrings
# Use team naming conventions
# Move reusable logic to helpers.py
```
```javascript
// Refactor using modern JS patterns
// Rename variables for clarity
// Add inline documentation
```

---

## Tips
- Open all relevant files for best results.
- Use Copilot Chat to ask about cross-file logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---
