# Lab 2.1: Context-Aware Refactoring with GitHub Copilot Enterprise

## Scenario
You have joined a large enterprise team responsible for a hybrid Python-JavaScript application that processes internal financial data and serves it via a web UI. Over the years, the codebase has become inconsistent in naming, structure, and documentation.

Your task is to modernize and refactor the codebase to current standards—improving naming, modularity, and maintainability—while ensuring all integrations remain intact. You will leverage GitHub Copilot Enterprise features, including Copilot Chat, cross-file context, and knowledge bases, to perform consistent, large-scale refactoring across multiple files and languages.

The lab provides a dedicated `KB/` folder containing team-specific naming standards and refactoring templates. You are expected to use these resources to guide your changes and standardize your approach.

---

## Lab Objectives

In this lab, you will:

- Refactor legacy **Python** and **JavaScript** code in the `processor/` and `webui/` folders using Copilot Chat and Enterprise indexing.
- Apply naming conventions and refactoring strategies from the `KB/` knowledge base.
- Use team-standard prompt templates to ensure consistency and modularity.
- Annotate and restructure code for improved index-aware reuse.
- Write and update tests in the `tests/` folder to validate your changes.

---

## Learning Goals

- Refactor legacy code using modern naming and structure conventions.
- Leverage Copilot’s cross-file and knowledge base capabilities for consistent changes.
- Apply prompt engineering techniques and templates to guide Copilot in complex scenarios.
- Recognize Copilot’s limitations in isolated contexts and learn mitigation strategies.
- Document insights and best practices for using Copilot in large enterprise codebases.

---

## Folder Structure
```
Lab 2.1/
│
├── KB/
│   ├── naming-standards.md         # Team naming conventions
│   └── refactor-template.md        # Refactoring prompt templates
├── processor/
│   ├── legacy_data.py              # Outdated function names, unclear logic
│   └── helpers.py                  # Poor naming and redundant parameters
├── tests/
│   └── test_legacy_data.py         # Test cases for refactored code
├── webui/
│   └── frontend.js                 # JavaScript UI logic
└── problemstatement.md    			# This file
```

---


## Step-by-Step Instructions

### Step 1: Understand the Legacy Code
- Review `processor/legacy_data.py` and `processor/helpers.py`for unclear function names, tightly coupled logic, poor naming, and redundant parameters.
- Explore `webui/frontend.js` and identify repeated logic and outdated patterns.

### Step 2: Utilize the Knowledge Base (KB) Folder for Standardization
- Open the `KB/` folder and review `naming-standards.md` for your team's naming conventions and `refactor-template.md` for prompt templates.
- Reference these documents throughout the lab to ensure your refactoring aligns with team standards.
- When using Copilot Chat or writing prompts, copy relevant sections from the KB to guide Copilot’s suggestions (e.g., paste naming rules or templates into the chat or as comments in code).
- If you are unsure about a naming or refactoring decision, consult the KB first before proceeding.

### Step 3: Refactoring Tasks
Use the following standardized prompt template throughout the lab:

**Prompt Template:**
"Refactor this [function/module] to follow team conventions: clear naming, modular structure, consistent docstrings. Move reusable logic to helpers."

**Start applying it in:**

`legacy_data.py` → for unclear functions

`helpers.py` → to clean up utility functions

`frontend.js` → to modernize repeated blocks

Try the prompt via:

**Chat Mode (@Copilot):** Copy-paste the prompt and ask follow-ups

**Inline:** Add comments like # Refactor for modularity and clarity before a block

**Edit Mode:** Select the block → Copilot Labs → "Make this modern and readable"


### Step 4: Move Logic to helpers.py
Use Copilot to identify reusable logic. Move reusable logic from `legacy_data.py` to `helpers.py` with clear docstrings and type hints.

**Prompt:**
- "Which logic in `legacy_data.py` can be reused? Move them to `helpers.py` and write clear docstrings."
- Add annotations and type hints to make helpers index-aware and reusable.

### Step 5: Start Refactoring with GitHub Copilot
#### Use Inline Suggestions
- Begin by renaming confusing functions (e.g., `process_input_data`) and breaking large functions into smaller ones.
- Add a comment or docstring like:  
	`# This function should take a user dictionary and return a normalized format`  
	→ then hit `Tab` to let Copilot suggest a better function.

#### Use Chat Mode
- Ask:  
	`"Refactor the function in **legacy_data.py** to be modular and clear. Which parts should go to **helpers.py**?"`

#### Use Edit Mode (Copilot Labs)
- Select a function or block of logic, then click **Copilot > Edit > Make this modern and readable**.

### Step 6: Update `helpers.py`
- Move shared or utility logic here.
- Clean up parameter lists and docstrings using Copilot's suggestions.

### Step 7: Modernization
- Use comments to guide Copilot.   
	`// refactor repeated blocks and update to modern ES6+ syntax.`

### Step 8: Testing
- Update `tests/test_legacy_data.py` to match your refactored functions.
- Ask Copilot Chat:  
	`"Write new test cases for normalize_user_data in helpers.py"`

---

## Copilot Enterprise Features: Cross-File Context & Prompt Awareness

This lab demonstrates how **GitHub Copilot Enterprise** can:
- Understand and reference symbols across multiple files (within the repo).
- Suggest refactors even when definitions span files (`helpers.py`, `legacy_data.py`).
- Assist in updating tests based on refactored code automatically.
- Provide consistent documentation suggestions across modules.
- Leverage access to larger context windows and semantic repo indexing (if enabled on your Enterprise plan).
