// frontend.js

function getUserData(userList) {
    var result = []
    for (var i = 0; i < userList.length; i++) {
        var u = userList[i];
        result.push({
            name: u.n,
            id: u.i
        });
    }
    return result;
}

function getUserData(userList) {
    // duplicate function for same purpose
    let users = [];
    userList.forEach(u => {
        users.push({ name: u.n, id: u.i });
    });
    return users;
}
