# legacy_data.py

def extract(d):
    # Extracts values from a dictionary assuming fixed structure
    val1 = d.get('v1')
    val2 = d.get('v2')
    val3 = d.get('v3')
    return val1, val2, val3

def clean(data):
    # Cleans up the data by removing unwanted characters
    return [str(d).replace('-', '').strip() for d in data]

def run_all(ds):
    # Executes both extraction and cleanup
    extracted = [extract(d) for d in ds]
    flat = [item for sublist in extracted for item in sublist]
    return clean(flat)
