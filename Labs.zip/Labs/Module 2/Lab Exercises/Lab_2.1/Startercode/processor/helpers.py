# helpers.py

def calculateTotal(A, B, C):
    return A + B + C

def formatInfo(user_name, USER_ID):
    return f"{user_name.lower()}_{USER_ID.lower()}"

def clean_data(data: list) -> list:
    cleaned =[]
    return cleaned
