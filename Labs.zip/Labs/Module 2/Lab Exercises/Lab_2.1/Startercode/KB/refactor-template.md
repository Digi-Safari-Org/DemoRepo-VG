# Team Refactor Prompt Template

**Purpose:**  
Use this prompt when modernizing legacy code to ensure consistency in naming, structure, and modularity across the project.

---

**Prompt:**  
Refactor this [function/module/file] to follow team conventions:  
- Clear, descriptive naming  
- Modular, reusable structure  
- Consistent docstrings (Google-style for Python, JSDoc for JavaScript)  
- Remove duplicate logic and move shared code to helpers  
- Add type hints (Python) or JSDoc type annotations (JavaScript)  
- Maintain backward compatibility with existing integrations

---

**Example Usage in Chat:**  
_"Refactor `process_input_data` in legacy_data.py to match team standards. Move reusable logic to helpers.py, ensure docstrings are clear, and add type hints."_  

**Example Inline Comment:**  
```
#python
# Refactor for modularity and clarity → move reusable logic to helpers.py

//JS
// Refactor this function to ES6 syntax and remove duplication
```