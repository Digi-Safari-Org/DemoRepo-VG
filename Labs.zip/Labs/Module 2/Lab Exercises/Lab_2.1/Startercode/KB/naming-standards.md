
---

## **`kb-prompts/naming-standards.md`**
```markdown
# Naming Standards Guide

**General Rules:**
- **Functions & Methods:** Verb-based, lowercase_with_underscores (Python) / camelCase (JavaScript)
- **Classes:** PascalCase
- **Constants:** ALL_CAPS_WITH_UNDERSCORES
- **Variables:** Descriptive, lowercase_with_underscores (Python) / camelCase (JavaScript)
- **Modules/Files:** snake_case (Python) / kebab-case (JavaScript)

---

**Python Examples:**
❌ `doData()` → ✅ `process_data()`  
❌ `calcval` → ✅ `calculate_value()`  

**JavaScript Examples:**
❌ `doData()` → ✅ `processData()`  
❌ `valCalc` → ✅ `calculateValue()`  

---

**Docstring/JSDoc Notes:**
- **Python:** Use Google-style docstrings with Args, Returns, Raises
- **JavaScript:** Use JSDoc format with `@param`, `@returns`
