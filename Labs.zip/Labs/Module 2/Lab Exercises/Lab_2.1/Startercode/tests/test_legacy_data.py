# test_legacy_data.py

import unittest
from processor.legacy_data import extract, clean

class TestLegacyData(unittest.TestCase):

    def test_extract(self):
        sample = {'v1': 10, 'v2': 20, 'v3': 30}
        self.assertEqual(extract(sample), (10, 20, 30))

    def test_clean(self):
        dirty = [' 123 ', '4-56', ' 78-9 ']
        cleaned = clean(dirty)
        self.assertEqual(cleaned, ['123', '456', '789'])

if __name__ == '__main__':
    unittest.main()
