# In-memory "database" simulation
database = []

"""
Simulates processing user data with multiple responsibilities.
Current version is messy and violates single-responsibility principle.
Students must refactor it using Copilot Chat.
"""
def process_user_data(user_data):
    # Validate email
    if "email" not in user_data or "@" not in user_data["email"]:
        print("Invalid email")
        return

    # Generate user ID
    import random
    user_id = random.randint(10000, 99999)
    print(f"Generated user ID: {user_id}")

    # Save to database
    existing_user_index = next((i for i, u in enumerate(database) if u["email"] == user_data["email"]), None)
    if existing_user_index is not None:
        database[existing_user_index] = {**user_data, "id": user_id}
        print("User updated in database")
    else:
        database.append({**user_data, "id": user_id})
        print("User added to database")

    # Print final database state
    print("Current database:", database)


"""
TODO: Implement this reusable enterprise logging function.
All logs must be in format:
[MY_APP] - [MODULE_NAME] - [LEVEL] - Actual message
"""
def log_message(module_name, level, message):
    print(f"[MY_APP] - {module_name} - {level} - {message}")


# Example calls for testing ( should keep & extend these)
if __name__ == "__main__":
    process_user_data({"email": "test@example.com", "name": "Alice"})
    process_user_data({"email": "invalidemail", "name": "Bob"})
