# Copilot Prompts and Lab Steps for Module 2 

## Lab 2.3: Refactoring and Standardizing Code with Copilot Chat

**Copilot Prompt:**
```
Refactor the following monolithic Python function into modular helper functions. Requirements:
1. Break it into smaller functions (e.g., validate_email, generate_user_id, save_user_to_db)
2. Replace print statements with a reusable enterprise logging function: log_message(message, level)
3. Ensure all helper functions are reusable and properly documented
4. Provide test cases at the end (in a __main__ block) to verify:
   - Each helper function works correctly
   - The main function behaves correctly for valid and invalid inputs
   - Logging appears in the correct enterprise format

Function code:

def process_user_data(user, db):
    # ...
```

**Steps to Complete:**
1. Open `Lab_2.3/main.py` and identify the monolithic function and its responsibilities (validation, ID generation, DB ops).
2. Use Copilot Chat to break the function into smaller helpers:
   - `validate_email(email)`
   - `generate_user_id()`
   - `save_user_to_db(db, user)`
3. Replace all print/logging with a reusable `log_message(message, level)` function that follows `[APP_NAME] - [MODULE_NAME] -` format.
4. Add test cases in a `__main__` block to verify:
   - Each helper works as expected
   - The main function handles valid/invalid input
   - Logging is in the correct format
5. Run and review the output to ensure correctness and enterprise compliance.

---


