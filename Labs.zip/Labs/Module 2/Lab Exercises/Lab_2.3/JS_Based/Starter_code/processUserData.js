const database = [];

/**
 * Simulates processing user data with multiple responsibilities.
 * Current version is messy and violates single-responsibility principle.
 * Students must refactor it using Copilot Chat.
 */
function processUserData(userData) {
    // Validate email
    if (!userData.email || !userData.email.includes("@")) {
        console.log("Invalid email");
        return;
    }

    // Generate user ID
    const userId = Math.floor(Math.random() * 100000);
    console.log(`Generated user ID: ${userId}`);

    // Save to database
    const existingUserIndex = database.findIndex(u => u.email === userData.email);
    if (existingUserIndex !== -1) {
        database[existingUserIndex] = { ...userData, id: userId };
        console.log("User updated in database");
    } else {
        database.push({ ...userData, id: userId });
        console.log("User added to database");
    }

    // Print final database state
    console.log("Current database:", database);
}

/**
 * TODO: Implement this reusable enterprise logging function
 */
function logMessage(moduleName, level, message) {
    console.log(`[MY_APP] - ${moduleName} - ${level} - ${message}`);
}

// Example calls for testing
processUserData({ email: "test@example.com", name: "Alice" });
processUserData({ email: "invalidemail", name: "Bob" });

module.exports = { processUserData, logMessage, database };


