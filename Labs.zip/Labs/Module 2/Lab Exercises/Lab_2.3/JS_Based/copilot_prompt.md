# Copilot Prompts and Lab Steps for Module 2

## Lab 2.3: Refactoring and Standardizing Code with Copilot Chat (JavaScript)

**Copilot Prompt:**
```
Refactor the following monolithic JavaScript function into modular helper functions. Requirements:
1. Break it into smaller functions (e.g., validateEmail, generateUserId, saveUserToDB)
2. Replace console.log statements with a reusable enterprise logging function: logMessage(moduleName, level, message)
3. Ensure all helper functions are reusable and properly documented
4. Provide test cases at the bottom to verify:
   - Each helper function works correctly
   - The main function behaves correctly for valid and invalid inputs
   - Logging appears in the correct enterprise format

Function code:

function processUserData(user, db) {
  const emailRegex = /\S+@\S+\.\S+/;
  if (!emailRegex.test(user.email)) {
    console.log(`Invalid email for user ${user.name}`);
    return null;
  }
  const userId = 'user_' + Math.floor(Math.random() * 1000);
  db.push({ id: userId, ...user });
  console.log(`User ${user.name} added with ID ${userId}`);
  return { id: userId, ...user };
}
```

**Steps to Complete:**
1. Open `Lab_2.3/processUserData.js`.
2. Identify the monolithic function and its responsibilities (validation, ID generation, DB ops).
3. Use Copilot Chat to break the function into smaller helpers:
   - `validateEmail(email)`
   - `generateUserId()`
   - `saveUserToDB(db, user)`
4. Replace all `console.log` with a reusable `logMessage(moduleName, level, message)` function.
5. Add test cases at the bottom to verify:
   - Each helper works as expected
   - The main function handles valid/invalid input
   - Logging is in the correct format
6. Run and review the output to ensure correctness and enterprise compliance.

---

