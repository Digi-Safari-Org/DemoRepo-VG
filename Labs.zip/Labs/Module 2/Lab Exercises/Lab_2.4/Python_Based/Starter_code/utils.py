"""
Utility functions for formatting, sanitization, and string transformations.

Students will:
- Implement the functions according to the provided specifications.
- Use type hints and rich docstrings.
- Ensure functions are reusable and index-friendly for Copilot in a large repo context.
"""

def format_currency(amount: float, currency_symbol: str = "$") -> str:
    """
    TODO: Return a formatted currency string with the given symbol.
    
    Args:
        amount (float): The numeric amount to format.
        currency_symbol (str, optional): Symbol to prepend. Defaults to "$".
    
    Returns:
        str: The formatted currency string.
    
    Example:
        >>> format_currency(19.99)
        '$19.99'
    """
    pass  


def sanitize_input(value: str) -> str:
    """
    TODO: Trim whitespace and remove illegal characters like \\n or \\t.
    
    Args:
        value (str): The string to sanitize.
    
    Returns:
        str: The cleaned string.
    
    Example:
        >>> sanitize_input("  Hello\\n")
        'Hello'
    """
    pass  


def convert_to_uppercase(value: str) -> str:
    """
    TODO: Convert the string to uppercase for standardizing product codes.
    
    Args:
        value (str): The string to transform.
    
    Returns:
        str: Uppercase version of the string.
    
    Example:
        >>> convert_to_uppercase("abc")
        'ABC'
    """
    pass  
