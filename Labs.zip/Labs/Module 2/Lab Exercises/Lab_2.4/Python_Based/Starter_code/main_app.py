"""
Main application entry point for demonstrating cross-file utility function usage.

Students will:
- Simulate structured prompting as if using Copilot Chat.
- Use comments to guide Copilot into importing and applying utils.py functions.
- Validate behavior with assertions instead of print statements.
"""



# TODO: Expect Copilot to suggest the right imports here

# Example product data (students may change for testing)
product_name = "   deluxe chair\n"
product_price = 149.5

# TODO: Use sanitize_input() to clean product_name
# TODO: Use convert_to_uppercase() to standardize the name
# TODO: Use format_currency() to format the price

# TODO: Replace these placeholders after implementation
cleaned_name = None
formatted_price = None

# Assertions for validation
if __name__ == "__main__":
    # 1. Check sanitized and uppercased name
    assert cleaned_name == "DELUXE CHAIR", "Product name cleaning/uppercasing failed."

    # 2. Check currency formatting
    assert formatted_price == "$149.50", "Currency formatting failed."

    # 3. Edge case: Empty string should raise ValueError
    try:
        _ = sanitize_input("")
    except ValueError:
        pass
    else:
        raise AssertionError("Empty input did not raise ValueError.")

    print("All tests passed!")
