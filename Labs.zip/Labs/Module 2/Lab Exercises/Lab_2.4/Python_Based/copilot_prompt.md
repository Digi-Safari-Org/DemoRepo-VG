# Copilot Prompts and Lab Steps for Module 2 (Python)

## Lab 2.4: Index-Aware Prompting and Cross-File Code Reuse

**Copilot Prompt:**
```
# COPILOT PROMPT SCAFFOLD
# Goal: Display a product name and price using helpers from utils.py
# Requirements:
# 1) Clean the product name using sanitize_input
# 2) Uppercase the cleaned name using convert_to_uppercase
# 3) Format the price using format_currency with a currency symbol
#
# Desired API:
# - from utils import sanitize_input, convert_to_uppercase, format_currency
# - raw_name = "  deluxe\twidget\n "
# - raw_price = 1299.5
# - cleaned = sanitize_input(raw_name)
# - name = convert_to_uppercase(cleaned)
# - price = format_currency(raw_price, "₹")
# - print(f"{name} - {price}")
#
# Please suggest the imports and exact usage in order.
```

**Steps to Complete:**
1. Open `Lab_2.4/utils.py` and define at least three helper functions:
   - `format_currency(amount: float, currency_symbol: str = "$") -> str`
   - `sanitize_input(value: str) -> str`
   - `convert_to_uppercase(value: str) -> str`
2. Add complete type hints and rich docstrings for each function.
3. In `Lab_2.4/main.py`, add prompt-style comments describing the goal and requirements.
4. Use Copilot to generate the correct imports and usage order for the helpers.
5. Implement the logic to clean, uppercase, and format the product name and price.
6. Add assertion tests to verify:
   - The sanitized and uppercased product name matches expectations
   - The formatted price is correct
   - Invalid inputs throw appropriate errors
7. Print "✅ All validations passed!" if all tests succeed.

