# Copilot Prompts and Lab Steps for Module 2
## Lab 2.4: Index-Aware Prompting and Cross-File Code Reuse (JavaScript Version)

**Copilot Prompt:**
```
// COPILOT PROMPT SCAFFOLD
// Goal: Display a product name and price using helpers from utils.js
// Requirements:
// 1) Clean the product name using sanitizeInput
// 2) Uppercase the cleaned name using convertToUppercase
// 3) Format the price using formatCurrency with a currency symbol
//
// Desired API:
// - import { sanitizeInput, convertToUppercase, formatCurrency } from "./utils.js";
// - const rawName = "  deluxe\twidget\n ";
// - const rawPrice = 1299.5;
// - const cleaned = sanitizeInput(rawName);
// - const name = convertToUppercase(cleaned);
// - const price = formatCurrency(rawPrice, "₹");
// - console.log(`${name} - ${price}`);
//
// Please suggest the imports and exact usage in order.
```

**Steps to Complete:**
1. Open `Lab_2.4/utils.js` and define at least three helper functions:
   - `formatCurrency(amount, currencySymbol = "$")`
   - `sanitizeInput(value)`
   - `convertToUppercase(value)`
2. Add complete JSDoc comments and examples for each function.
3. In `Lab_2.4/main_app.js`, add prompt-style comments describing the goal and requirements.
4. Use Copilot to generate the correct imports and usage order for the helpers.
5. Implement the logic to clean, uppercase, and format the product name and price.
6. Add at least three assertion tests to verify:
   - The sanitized and uppercased product name matches expectations
   - The formatted price is correct
   - Invalid inputs throw appropriate errors
7. Log "✅ All validations passed!" if all tests succeed.
