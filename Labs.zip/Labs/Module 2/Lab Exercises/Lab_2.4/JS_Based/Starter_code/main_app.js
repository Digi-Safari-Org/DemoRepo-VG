const productName = "   deluxe\twidget\n ";
const productPrice = 1299.5;

// TODO: Use sanitizeInput() to clean productName
// TODO: Use convertToUppercase() to standardize the name
// TODO: Use formatCurrency() to format the price

let cleanedName;
let formattedPrice;

if (require.main === module) {
    // 1. Check sanitized and uppercased name
    const assert = require("assert");
    assert.strictEqual(cleanedName, "DELUXE WIDGET", "Product name cleaning/uppercasing failed.");

    // 2. Check currency formatting
    assert.strictEqual(formattedPrice, "$1,299.50", "Currency formatting failed.");

    // 3. Edge case: Empty string should throw an error
    try {
        sanitizeInput("");
        assert.fail("Expected sanitizeInput to throw an error for empty input.");
    } catch (err) {
        assert.ok(/empty/i.test(err.message), "Error message should mention 'empty'.");
    }

    console.log("✅ All validations passed!");
}