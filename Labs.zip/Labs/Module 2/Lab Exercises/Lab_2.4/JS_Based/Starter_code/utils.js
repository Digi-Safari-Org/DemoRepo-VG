/**
 * Formats a number as a currency string.
 *
 * @param {number} amount - The numeric amount to format.
 * @param {string} [currencySymbol="$"] - The symbol to prepend to the formatted amount.
 * @returns {string} The formatted currency string.
 *
 * @example
 * formatCurrency(19.99, "$"); // "$19.99"
 */
export function formatCurrency(amount, currencySymbol = "$") {
    // TODO: Implement currency formatting
    // HINT: Use toFixed(2) and string concatenation or Intl.NumberFormat
    throw new Error("Not implemented");
}

/**
 * Removes leading/trailing whitespace and illegal characters (\n, \t) from a string.
 *
 * @param {string} value - The input string to sanitize.
 * @returns {string} The sanitized string.
 *
 * @throws {Error} If value is not a string or results in an empty string after cleaning.
 *
 * @example
 * sanitizeInput("  Deluxe\tWidget\n"); // "Deluxe Widget"
 */
export function sanitizeInput(value) {
    // TODO: Implement input sanitization
    throw new Error("Not implemented");
}

/**
 * Converts a string to uppercase.
 *
 * @param {string} value - The input string.
 * @returns {string} The uppercase version of the string.
 *
 * @throws {Error} If value is not a string.
 *
 * @example
 * convertToUppercase("hello"); // "HELLO"
 */
export function convertToUppercase(value) {
    // TODO: Implement uppercase conversion
    throw new Error("Not implemented");
}
