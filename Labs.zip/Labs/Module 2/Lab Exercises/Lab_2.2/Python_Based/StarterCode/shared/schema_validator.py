# Add full docstrings and reuse across files
# Prompt: Document this function properly and ensure validation aligns with team standards

def validate_user_payload(payload):
    if "name" not in payload or not payload["name"]:
        raise ValueError("Missing or empty name field")
    if "age" not in payload or not isinstance(payload["age"], int):
        raise ValueError("Missing or invalid age field")
    return True
