# Legacy code with inconsistent logic - Refactor using team standards
# Prompt: Refactor this to use shared validation and follow naming and logging conventions

def ValidateInput(user_input):
    if user_input.get("name") == "" or user_input.get("age") == None:
        print("Invalid input")  
        return False
    return True
