# Legacy ETL logic in one function - Break into smaller functions, rename, and document
# Prompt: Refactor this using team guidelines: split logic, rename in snake_case, add docstrings, use logger

def TransformRecords(data):
    import pandas as pd
    df = pd.DataFrame(data)
    df['full_name'] = df['first'] + " " + df['last']
    df = df.dropna()
    print("Transform done")  
    return df
