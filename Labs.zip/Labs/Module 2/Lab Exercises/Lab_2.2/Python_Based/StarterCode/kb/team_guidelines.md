# Team Python Guidelines

## Function Naming
- Use snake_case for all functions.
- Avoid abbreviations unless common (e.g., `df`, `url`).

## Logging
- Use `logger_util.get_logger(module_name)` across all scripts.
- Do not use `print()` for output.

## Error Handling
- Raise specific exceptions (`ValueError`, `KeyError`) with clear messages.
- Avoid catching broad exceptions.

## Docstring Format
Use Google style:

```python
def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cleans input DataFrame by removing nulls and standardizing columns.

    Args:
        df (pd.DataFrame): Raw data

    Returns:
        pd.DataFrame: Cleaned data
    """
