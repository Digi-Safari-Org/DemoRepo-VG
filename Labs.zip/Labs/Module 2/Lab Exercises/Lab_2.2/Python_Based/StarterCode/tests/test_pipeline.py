# Tests outdated function names and signatures
# Prompt: Update test to match refactored function and structure

import unittest
from pipeline.transform_records import TransformRecords  # May need to update after refactor

class TestPipeline(unittest.TestCase):
    def test_transform(self):
        input_data = [{"first": "John", "last": "Doe"}]
        result = TransformRecords(input_data)
        self.assertIn("full_name", result.columns)

if __name__ == "__main__":
    unittest.main()
