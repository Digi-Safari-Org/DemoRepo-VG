# Copilot Prompt Guide for Lab 2.2: Standardizing Data Pipelines with Copilot Enterprise

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the standardization and refactoring tasks in Lab 2.2. Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity.

---

## Prompts for Knowledge Base Integration

### 1. Upload Team Guidelines
**Prompt:**
> Upload `kb/team-guidelines.md` to the Copilot Knowledge Base for context-aware suggestions.

---

## Prompts for Refactoring ETL Code (`pipeline/transform_records.py`)

### 1. Refactor with Team Standards
**Prompt:**
> Refactor this file using our team guidelines. Break large functions, rename with snake_case, add Google-style docstrings.

### 2. Move Reusable Logic
**Prompt:**
> # Move reusable transformation logic to shared module

---

## Prompts for Cross-File Context (`pipeline/validate_input.py`)

### 1. Import and Use Shared Validators
**Prompt:**
> from shared.schema_validator import validate_user_payload

### 2. Understand Validator Usage
**Prompt:**
> How does `validate_user_payload` work? Should I use it here?

---

## Prompts for Prompt Templates (`.github/copilot/prompt-templates.json`)

### 1. Add Standard Refactor Template
**Prompt:**
> Add the following template:
```
{
  "templates": [
    {
      "name": "StandardFunctionRefactor",
      "prompt": "Refactor this function to:\n- Follow snake_case naming\n- Add Google-style docstrings\n- Raise specific exceptions\n- Log using shared logger"
    }
  ]
}
```

### 2. Use Template in Copilot Chat
**Prompt:**
> Refactor this function using the "StandardFunctionRefactor" template.

---

## Prompts for Logger Annotation (`shared/logger_util.py`)

### 1. Add Structured Docstring and Usage Example
**Prompt:**
> """
Shared logger setup for all Python scripts.

Usage:
    from shared.logger_util import get_logger
    logger = get_logger(__name__)
    logger.info("Initialized")
"""

### 2. Annotate for Future Reuse
**Prompt:**
> Annotate this for future reuse across pipelines.

---

## Prompts for Validation and Testing

### 1. Use Shared Validators
**Prompt:**
> Use shared `schema_validator` functions for input checks in pipeline modules.

### 2. Update and Expand Tests
**Prompt:**
> Review `test_pipeline.py` and update tests to match refactored function signatures. Add new tests for edge cases and error handling.

---

## Prompts for Copilot Chat in GitHub.com UI

### 1. Summarize and Review Changes
**Prompt:**
> What was changed in `transform_records.py`? Were naming conventions followed?

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```python
# Refactor for clarity and modularity
# Add type hints and docstrings
# Use team naming conventions
# Move reusable logic to shared modules
# Add robust error handling
```

---

## Tips
- Open all relevant files for best results.
- Use Copilot Chat to ask about cross-file logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---
