# Lab Challenge: Standardizing Data Pipelines Across Teams with GitHub Copilot Enterprise

## Scenario

Your organization has several teams building Python data pipelines — but over time, the code has diverged in style, naming, and function structure. A new initiative mandates standardization across all pipelines, including:

- Naming conventions  
- Logging patterns  
- Test coverage  
- Code modularity  
- Reuse of shared utilities  

You are assigned to lead the standardization effort using GitHub Copilot Enterprise features like:

- Cross-file context for large codebase refactoring  
- Copilot Chat for intelligent guidance  
- Prompt templates to guide your team  
- Knowledge Base integration to align with internal conventions  
- Annotation for index-aware reuse of logging & validation tools

---


## Folder Structure

```
data-standardization-lab/
│
├── pipeline/
│   ├── validate_input.py       # Inconsistent logic and poor structure
│   ├── transform_records.py    # Legacy ETL logic in one function
│
├── shared/
│   ├── logger_util.py          # Logging setup that can be reused
│   ├── schema_validator.py     # Partially documented validators
│
├── tests/
│   └── test_pipeline.py        # Tests outdated function signatures
│
├── .github/
│   └── copilot/
│       └── prompt-templates.json
│
└── kb/
    └── team-guidelines.md      # 👈 Upload to Copilot Knowledge Base
```
### Knowledge Base Upload
- **upload**: kb/team-guidelines.md to the Copilot Knowledge Base.


It includes:

✅ Function naming conventions

✅ Logging requirements

✅ Preferred error-handling strategies

✅ Example docstring formats

✅ Standard validation schemas

✅ Common anti-patterns to avoid

### Validation
Use shared schema_validator functions for input checks.

## Step-by-Step Tasks

### Task 1: Upload the Knowledge Base  
 **Topic**: Creating consistent prompts using Copilot Knowledge Bases

1. Open the **Copilot Chat sidebar**
2. Click **"Upload Knowledge Base"**
3. Upload: `kb/team-guidelines.md`


### Task 2: Refactor ETL Code Using Copilot Chat  
 **Topic**: Refactoring legacy code in large monorepos

1. Open: `pipeline/transform_records.py`
2. Use Copilot Chat and ask:
    ```
    Refactor this file using our team guidelines.
    Break large functions, rename with snake_case, add Google-style docstrings.
    ```
3. Add inline prompts like:
    ```python
    # Move reusable transformation logic to shared module
    ```

---

### Task 3: Enable Cross-File Context  
 **Topic**: Enabling cross-file context with Enterprise indexing

1. Open: `pipeline/validate_input.py`
2. Import from shared modules:
    ```python
    from shared.schema_validator import validate_user_payload
    ```
3. Ask Copilot Chat:
    ```
    How does validate_user_payload work? Should I use it here?
    ```
Copilot Chat should use enterprise-level indexing to provide helpful answers.

---

### Task 4: Apply Prompt Templates  
 **Topic**: Defining team-specific prompt templates

1. Open: `.github/copilot/prompt-templates.json`
2. Add the following template:

```json
{
  "templates": [
    {
      "name": "StandardFunctionRefactor",
      "prompt": "Refactor this function to:\n- Follow snake_case naming\n- Add Google-style docstrings\n- Raise specific exceptions\n- Log using shared logger"
    }
  ]
}
```

3. Select a legacy function in pipeline/ and use the prompt via Copilot Chat.

### Task 5: Annotate for Index-Aware Reuse
**Topic**: Annotating and restructuring code for semantic reuse

**Open**: shared/logger_util.py

- Add structured docstring and usage example:
```
"""
Shared logger setup for all Python scripts.

Usage:
    from shared.logger_util import get_logger
    logger = get_logger(__name__)
    logger.info("Initialized")
"""
```

**Ask Copilot Chat:**
```
Annotate this for future reuse across pipelines.
```
This enables Copilot to suggest get_logger() in other projects due to indexing.

### Additional:
- Create a Pull Request
- Use Copilot Chat on GitHub.com to summarize:
```
What was changed in transform_records.py?
Were naming conventions followed?
```