# Lab 2.2: Standardizing Data Pipelines Across Teams with GitHub Copilot Enterprise (JS)

## Scenario
Your organization has several teams building JavaScript data pipelines — but over time, the code has diverged in style, naming, and function structure. A new initiative mandates standardization across all pipelines, including:

- Naming conventions
- Logging patterns
- Test coverage
- Code modularity
- Reuse of shared utilities

You are assigned to lead the standardization effort using GitHub Copilot Enterprise features like:
- Cross-file context for large codebase refactoring
- Copilot Chat for intelligent guidance
- Prompt templates to guide your team
- Knowledge Base integration to align with internal conventions
- Annotation for index-aware reuse of logging & validation tools

---

## Folder Structure
```
Lab 2.2/Starter Code/
│
├── pipeline/
│   ├── validate_input.js       // Inconsistent logic and poor structure
│   ├── transform_records.js    // Legacy ETL logic in one function
│
├── shared/
│   ├── logger_util.js          // Logging setup that can be reused
│   ├── schema_validator.js     // Partially documented validators
│
├── tests/
│   └── test_pipeline.js        // Tests outdated function signatures
│
└── kb/
    └── team-guidelines.md      // 👈 Upload to Copilot Knowledge Base Repo
```

### Knowledge Base Upload
- **upload**: kb/team-guidelines.md to the Copilot Knowledge Base Repo.

It includes:
✅ Function naming conventions
✅ Logging requirements
✅ Preferred error-handling strategies
✅ Example docstring formats
✅ Standard validation schemas
✅ Common anti-patterns to avoid

### Validation
Use shared schema_validator functions for input checks.

## Step-by-Step Tasks

### Task 1: Upload the Knowledge Base
**Topic**: Creating consistent prompts using Copilot Knowledge Bases 
1. Upload: `team-guidelines.md`

### Task 2: Refactor ETL Code Using Copilot Chat
**Topic**: Refactoring legacy code in large monorepos
1. Open: `pipeline/transform_records.js`
2. Use Copilot Chat and ask:
    ```
    Refactor this file using our team guidelines.
    Break large functions, rename with camelCase, add JSDoc comments.
    ```
3. Add inline prompts like:
    ```js
    // Move reusable transformation logic to shared module
    ```

### Task 3: Enable Cross-File Context
**Topic**: Enabling cross-file context with Enterprise indexing
1. Open: `pipeline/validate_input.js`
2. Import from shared modules:
    ```js
    const { validateUserPayload } = require('../shared/schema_validator');
    ```
3. Ask Copilot Chat:
    ```
    How does validateUserPayload work? Should I use it here?
    ```
Copilot Chat should use enterprise-level indexing to provide helpful answers.

### Task 4: Apply Prompt Templates
**Topic**: Defining team-specific prompt templates
1. Open: `.github/copilot/prompt-templates.json`
2. Add the following template:
```json
{
  "templates": [
    {
      "name": "StandardFunctionRefactor",
      "prompt": "Refactor this function to:\n- Follow camelCase naming\n- Add JSDoc comments\n- Raise specific exceptions\n- Log using shared logger"
    }
  ]
}
```
3. Select a legacy function in pipeline/ and use the prompt via Copilot Chat.

### Task 5: Annotate for Index-Aware Reuse
**Topic**: Annotating and restructuring code for semantic reuse
**Open**: shared/logger_util.js
- Add structured JSDoc and usage example:
```js
/**
 * Shared logger setup for all JS scripts.
 *
 * Usage:
 *   const { getLogger } = require('../shared/logger_util');
 *   const logger = getLogger('myModule');
 *   logger.info('Initialized');
 */
```
**Ask Copilot Chat:**
```
Annotate this for future reuse across pipelines.
```
This enables Copilot to suggest getLogger() in other projects due to indexing.

### Additional:
- Create a Pull Request
- Use Copilot Chat on GitHub.com to summarize:
```
What was changed in transform_records.js?
Were naming conventions followed?
```
