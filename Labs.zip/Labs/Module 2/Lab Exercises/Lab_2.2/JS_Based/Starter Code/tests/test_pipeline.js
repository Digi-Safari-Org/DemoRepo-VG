// test_pipeline.js
// Tests for pipeline logic (JS version)
const { transformRecords } = require('../pipeline/transform_records');
const { validateInput } = require('../pipeline/validate_input');

describe('Pipeline Tests', () => {
    it('should transform records', () => {
        const records = [{ id: 1, name: 'Alice' }];
        const result = transformRecords(records);
        expect(result[0].transformed).toBe(true);
    });

    it('should validate input', () => {
        const payload = { id: 1, name: 'Alice' };
        expect(validateInput(payload)).toBe(true);
    });
});
