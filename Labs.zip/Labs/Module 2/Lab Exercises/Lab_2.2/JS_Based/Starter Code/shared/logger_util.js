// logger_util.js
// Shared logger setup 
function getLogger(name) {
    return {
        info: (msg) => console.log(`[${name}] ${msg}`),
        error: (msg) => console.error(`[${name}] ERROR: ${msg}`)
    };
}

module.exports = { getLogger };
