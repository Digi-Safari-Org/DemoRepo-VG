// validate_input.js
// Input validation logic 
const { validateUserPayload } = require('../shared/schema_validator');

function validateInput(payload) {
    return validateUserPayload(payload);
}

module.exports = { validateInput };
