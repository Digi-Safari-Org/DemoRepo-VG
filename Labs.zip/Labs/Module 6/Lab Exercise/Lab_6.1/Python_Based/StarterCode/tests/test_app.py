import unittest
from src import app

class TestApp(unittest.TestCase):
    def test_main_runs(self):
        try:
            app.main()
        except Exception as e:
            self.fail(f"App main() raised {e} unexpectedly!")

if __name__ == "__main__":
    unittest.main()
