import unittest
from src.data_processor import process_data

class TestDataProcessor(unittest.TestCase):
    def test_process_data(self):
        result = process_data(["a", "b"])
        self.assertEqual(result, ["A", "B"])

if __name__ == "__main__":
    unittest.main()
