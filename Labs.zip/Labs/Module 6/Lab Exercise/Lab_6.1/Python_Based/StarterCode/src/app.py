# Copilot Prompt: Summarize the purpose of this repository and list the main components. Paste the summary into docs/wiki/overview.md.
# Copilot Prompt: Add a one-line description of this file's role to the wiki.

from utils import greet_user
from data_processor import process_data
from report_generator import generate_report
from telemetry import log_performance

def main():
    print("=== Enterprise Data Processing App ===")
    user = "Developer"
    greet_user(user)

    data = ["alpha", "beta", "gamma"]
    processed = process_data(data)
    generate_report(processed)
    log_performance("main", 1.23)

if __name__ == "__main__":
    main()
