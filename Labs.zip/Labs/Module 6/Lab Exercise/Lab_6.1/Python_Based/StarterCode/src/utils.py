# To Do: Add utility functions for data processing
# Copilot Prompt: Add a one-line description of this file's role to the wiki.
# Copilot Prompt: Highlight the complex_transformation() function and ask Copilot to explain what it does in plain English for documentation purposes. Paste the explanation into docs/wiki/overview.md.
# Copilot Prompt: Add or improve docstrings for all functions in this file.

def greet_user(name):
    print(f"Hello, {name}! Welcome to the project.")

def helper_function(x):
    # TODO: Add meaningful comment
    return x[::-1]
