# Copilot Prompt: Add a one-line description of this file's role to the wiki.
# Copilot Prompt: Add inline comments to explain performance logging functions, including how telemetry could be used for optimization.
# Copilot Prompt: Suggest improvements, such as logging telemetry data to a file instead of printing.

import time

def log_performance(function_name, duration):
    print(f"[Telemetry] {function_name} executed in {duration:.2f} seconds")

def measure_execution_time(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        duration = time.time() - start
        log_performance(func.__name__, duration)
        return result
    return wrapper
