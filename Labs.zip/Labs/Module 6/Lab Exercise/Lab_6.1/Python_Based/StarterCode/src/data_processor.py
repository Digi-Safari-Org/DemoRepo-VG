def process_data(data):
    """Process a list of strings by capitalizing them."""
    processed = [item.upper() for item in data]
    return processed

def complex_transformation(data):
    # Simulated complex logic for telemetry-aware commenting
    output = []
    for idx, val in enumerate(data):
        transformed = f"{val}_{idx**2}"
        output.append(transformed)
    return output
