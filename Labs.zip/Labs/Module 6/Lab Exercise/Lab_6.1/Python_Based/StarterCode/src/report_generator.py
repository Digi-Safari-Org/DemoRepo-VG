def generate_report(data):
# Copilot Prompt: Add a one-line description of this file's role to the wiki.
# Copilot Prompt: Add or improve docstrings for all functions in this file.
    print("=== REPORT ===")
    for item in data:
        print(f"- {item}")
