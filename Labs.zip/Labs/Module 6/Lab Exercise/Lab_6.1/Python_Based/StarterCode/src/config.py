# Configuration file for enterprise application

APP_NAME = "Enterprise Data Processing App"
VERSION = "0.1.0"
