# Lab 6.1: AI-Assisted Documentation & Codebase Navigation with GitHub Copilot Enterprise 

## Objective
In this lab, you will use GitHub Copilot Enterprise to:
- Write and improve project documentation (README, CHANGELOG, CONTRIBUTING)
- Auto-explain code for wiki pages and reviews
- Add code comments with telemetry-aware insights
- Create and use GitHub Copilot Knowledge Bases
- Inject enterprise-specific context into documentation

---

## Prerequisites
- GitHub Enterprise Cloud account with **Copilot Enterprise** enabled
- Access to this starter repository
- **VS Code** or **GitHub Codespaces** with Copilot enabled
- Node.js 16+ and npm (or the Node version your enterprise standard uses)
- Basic familiarity with Markdown and JavaScript modules (ESM)

---
#### Part A: Core Documentation with Copilot

## Lab Steps

### **Step 1: Explore the Codebase**
**Files to open:** 
`src/app.js`, `src/utils.js`, `src/dataProcessor.js`, `src/reportGenerator.js`, `src/telemetry.js`  
1. Open the Starter Code folder in **VS Code**.
2. Use Copilot Chat to ask:
   ```
   Summarize the purpose of this repository and list the main components.
   ```
3. Copy the summary into `docs/wiki/overview.md`.
4. For each file above, add a one-line description in the wiki explaining its role.

---

### **Step 2: Create a Professional README**
**File to edit:** `README.md`  
1. Open `README.md` (currently has only a placeholder).
2. Ask Copilot:
   ```
   Generate a professional README for this repository including:
   - Overview
   - Installation instructions (npm install / node -v)
   - Usage examples (node src/app.js or npm start)
   - License section
   ```
3. Edit the generated text to match your enterprise style.
4. Include links to wiki pages and internal enterprise documentation.

---

### **Step 3: Generate a CHANGELOG**
**File to edit:** `CHANGELOG.md`  
1. Open `CHANGELOG.md` (currently empty).
2. Use Copilot prompt:
   ```
   Create a changelog for this project based on recent commits, using the Keep a Changelog format.
   ```
3. Validate that entries match the actual commit history.
4. Add an “Upcoming Features” section.

---

### **Step 4: Write CONTRIBUTING Guidelines**
**File to edit:** `CONTRIBUTING.md`  
1. Open `CONTRIBUTING.md` (currently empty).
2. Use Copilot:
   ```
   Generate a contributing guide for an enterprise open-source-style project. 
   Include coding standards, commit message format, pull request process, and security scanning requirements (pre-commit hooks, npm audit).
   ```
3. Adjust to include any enterprise-specific compliance rules.
4. Add instructions for running tests (e.g., `npm test`) and linting (`npm run lint`).

---

### **Step 5: Auto-Explain Code for Wiki**
**File to work with:** `src/dataProcessor.js`  
1. Highlight the `complexTransformation()` function (or equivalent).
2. Ask Copilot:
   ```
   Explain what this function does in plain English for documentation purposes.
   ```
3. Paste the explanation into the wiki page (`docs/wiki/overview.md`).
4. Repeat for any other functions that are not well-documented.

---
#### Part B: Enterprise Context & Advanced Copilot Features

### **Step 6: Add Telemetry-Aware Code Comments**
**File to edit:** `src/telemetry.js`  
1. Ask Copilot:
   ```
   Add inline comments to explain performance logging functions, 
   including how telemetry could be used for optimization.
   ```
2. Review and adjust for accuracy.
3. Suggest improvements, such as writing telemetry data to a file or exposing metrics for Prometheus.

---

### **Step 7: **Files to include to KB:**  
- `README.md`
- `CHANGELOG.md`
- `CONTRIBUTING.md`
- `docs/wiki/overview.md`  

Steps:
1. Add or commit those files to your repository (if they’re not already there).
2. In GitHub, go to Settings → Copilot → Knowledge Bases.
3. Link your Knowledge Base to the repository containing those files.
4. Wait for indexing to complete (this may take a few minutes).
5. Test by asking Copilot Chat in your IDE or GitHub:
   ```
   Where in the documentation does it explain how to deploy this project?
   ```

---

### **Step 8: Inject Enterprise Context**
**Files to update:** `README.md`, `CONTRIBUTING.md`, `docs/wiki/overview.md`  
1. Add internal documents such as:
   - Enterprise style guide
   - Security compliance checklist
2. Ask Copilot:
   ```
   Revise the README to include enterprise security compliance notes and approved deployment regions.
   ```
3. Commit the updated documentation.

---

## Expected Outcome
By the end of this lab, you will have:
- A completed README, CHANGELOG, and CONTRIBUTING file
- Wiki pages with AI-generated explanations
- Code with telemetry-aware comments
- A working Copilot Knowledge Base enriched with enterprise-specific context


