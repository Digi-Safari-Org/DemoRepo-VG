# Copilot Prompt Guide for Lab 6: Enterprise Data Processing & Telemetry 

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the data processing, reporting, and telemetry tasks in Lab 6. Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity for your Node.js project.

---

## Prompts for JS Project (`JS Based/Starter Code/`)

### 1. Analyze and Suggest Improvements
**Prompt:**
> Analyze `dataProcessor.js` and `telemetry.js` for modularity, error handling, and security. Suggest improvements based on enterprise standards.

### 2. Refactor and Add Documentation
**Prompt:**
> Refactor functions in `reportGenerator.js` for clarity and maintainability. Add JSDoc comments to all exported functions.

### 3. Implement Logging and Telemetry
**Prompt:**
> Review `telemetry.js` and `utils.js` for logging best practices. Suggest enhancements for audit trails and telemetry data collection.

### 4. Test Coverage and Edge Cases
**Prompt:**
> Generate Jest tests for `dataProcessor.js` covering edge cases, error scenarios, and input validation.

### 5. Review Contribution and Change Logs
**Prompt:**
> Review `CONTRIBUTING.md` and `CHANGELOG.md` for completeness and clarity. Suggest improvements to align with open-source standards.

---

## Cross-Project Context Prompts

### 1. Compare Data Processing Approaches
**Prompt:**
> Compare the data processing logic in `app.js` and `dataProcessor.js`. How can modularity and reusability be improved?

### 2. Security and Compliance
**Prompt:**
> Review the codebase for security and compliance risks. Suggest Copilot prompts to address potential vulnerabilities in data handling and telemetry.

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```javascript
// Refactor for modularity and error handling
// Add JSDoc comments for all functions
// Expand tests for edge cases and input validation
// Enhance logging and telemetry for audit trails
// Review for security and compliance risks
```

---

## Tips
- Open all relevant files for best results.
- Use Copilot Chat to ask about cross-file logic, dependencies, and documentation.
- Try Copilot’s suggestions, then review and refine as needed.

---
