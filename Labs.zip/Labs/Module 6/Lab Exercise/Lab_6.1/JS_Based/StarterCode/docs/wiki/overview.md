# Project Overview

> TODO: Summarize the purpose of this repository and list the main components using Copilot Chat.
