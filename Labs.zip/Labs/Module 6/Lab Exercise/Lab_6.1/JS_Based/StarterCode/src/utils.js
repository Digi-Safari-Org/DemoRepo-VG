// Utility functions

// TODO: Use Copilot to add helpful utility functions based on project needs.

export function formatDate(date) {
  return date.toISOString();
}
