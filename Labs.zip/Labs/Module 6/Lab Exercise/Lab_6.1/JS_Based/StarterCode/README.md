# Copilot Enterprise Doc Navigation Lab

> TODO: Use GitHub Copilot to generate a professional README as per lab instructions.

## Prompt for Learner:
```
Generate a professional README for this repository including:
- Overview
- Installation instructions (npm install / node -v)
- Usage examples (node src/app.js or npm start)
- License section
```
Edit the generated text to match your enterprise style and include links to wiki pages and internal enterprise documentation.
