/**
 * Fetches user data from an API and returns formatted object.
 * Telemetry: logs API calls for monitoring and audit purposes.
 *
 * @param {string} userId - Unique identifier of the user
 * @returns {Promise<object>} User object { id, name, email }
 * @example
 *   const user = await fetchUserData('123');
 *   console.log(user.name);
 *
 * @telemetry This function logs user data fetch events for compliance and monitoring.
 */
async function fetchUserData(userId) {
  // Telemetry: This log is required for audit/compliance tracking of user data access events.
  console.log(`Telemetry: fetching data for user ${userId}`);
  // Simulate API call
  return { id: userId, name: "John Doe", email: "john@example.com" };
}

module.exports = { fetchUserData };
