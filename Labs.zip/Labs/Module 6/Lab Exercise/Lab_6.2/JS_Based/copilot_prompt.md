# Copilot Prompt for Module 6: Documentation & Codebase Navigation

## Copilot Prompt
You are working on bringing a legacy microservice repository up to enterprise documentation standards. Your tasks include improving and creating documentation files, enforcing compliance, and enhancing codebase navigation. Follow the steps below to update the project documentation and code comments to meet enterprise requirements.

## Steps to Complete the Lab

1. **Improve the README.md**
   - Add structured sections: **Overview**, **Installation**, **Usage**, and **Enterprise Compliance Notes**.
   - Ensure compliance notes accurately reflect security and privacy requirements.

2. **Generate a CHANGELOG.md**
   - Use the commit history to create a changelog in the **Keep a Changelog** format.
   - Include all notable changes and add any missing release notes.

3. **Create a CONTRIBUTING.md**
   - Define clear contribution steps, branch naming conventions, commit message guidelines, pull request process, and review steps.
   - Include mandatory security review procedures and code ownership rules.

4. **Document a Complex Function**
   - Select a non-trivial function from the `/src` directory.
   - Write a clear explanation suitable for a project wiki and save it to `/docs/FunctionReference.md`.

5. **Add Telemetry-Aware Code Comments**
   - Identify any function that sends or logs telemetry data in the codebase.
   - Add docstrings describing telemetry-related behavior and compliance warnings.

6. **Add Enterprise-Specific Context to Documentation**
   - In `README.md`, add an **Enterprise Usage Policy** section outlining security clearance levels, data handling rules, and mandatory code scanning requirements.

7. **Commit and Push All Changes**
   - Stage all updated and new files, commit with clear messages, and push to the repository.

---

**Use GitHub Copilot Enterprise to draft, refine, and review all documentation and code comments for clarity, compliance, and completeness.**
