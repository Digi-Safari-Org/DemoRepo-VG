def process_order(data):
    # TODO: process order and return summary string
    summary = ""
    if "items" in data:
        for item in data["items"]:
            summary += f"{item['name']} x {item['qty']}, "
    if not data.get("customer_id"):
        return "Error: Missing customer ID"
    if "discount" in data:
        discount = data["discount"]
    else:
        discount = 0
    total = sum([item["price"]*item["qty"] for item in data.get("items", [])])
    total -= discount
    return summary + f"Total: ${total}"