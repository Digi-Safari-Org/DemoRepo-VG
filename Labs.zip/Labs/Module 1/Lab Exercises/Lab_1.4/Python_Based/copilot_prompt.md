# Copilot Prompts and Lab Steps for Module 1 (Python)

## Lab 1.4: Contextual Prompting for Code Reordering and Signature Upgrades

**Copilot Prompt:**
```
Given a Python function with mixed responsibilities and out-of-order statements, use Copilot Chat to:
1. Reorder the code into logical sections: input validation, data processing, output formatting.
2. Upgrade the function signature to use Python 3 type annotations and default arguments where appropriate.
3. Add a detailed comment block describing expected behavior, input/output types, and dependencies on utility functions from other files.
4. Use Copilot Chat with multi-file context to improve the implementation using available utilities.
```

**Steps to Complete:**
1. Open `Lab_1.4/main.py` and review the provided function.
2. Add a detailed comment block describing the function's purpose, expected input/output, and dependencies.
3. Use Copilot Chat to reorder the function into input validation, data processing, and output formatting sections.
4. Upgrade the function signature with type annotations and default arguments.
5. If the function uses utilities from other files, use Copilot Chat with project context to simplify the implementation.
6. Test the refactored function to ensure correctness.

---


