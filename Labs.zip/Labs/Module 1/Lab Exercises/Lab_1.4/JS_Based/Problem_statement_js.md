# Lab 1.4: Contextual Prompting for Code Reordering and Signature Upgrades in Large JavaScript Repos

### Objectives
    - Learn to write detailed, contextual prompts for Copilot Chat leveraging large internal repo context.

    - Practice reordering complex function code for readability and efficiency.

    - Upgrade function signatures with JSDoc type annotations and default parameter values.

    - Emphasize how Copilot Chat in GitHub UI or IDE can access multi-file context for better suggestions.

### Instructions
Part 1: Code Reordering for Readability
1. You are given a JavaScript function that contains mixed responsibilities and out-of-order statements, making it hard to read and maintain.

2. Using Copilot Chat, prompt it to reorder the statements logically into:

    - Input validation

    - Data processing

    - Output formatting

3. Provide Copilot with a detailed JSDoc comment describing the expected function behavior and input/output types for better suggestions.

Part 2: Signature Upgrade with JSDoc and Default Arguments
1. Upgrade the function signature to use JSDoc for all parameters and return types.

2. Introduce default argument values where applicable.

3. Use Copilot Chat contextual prompts to suggest idiomatic JavaScript signatures consistent with your enterprise’s coding standards.

Part 3: Using Copilot Chat with Multi-File Context
1. Assume this function depends on a utility function defined in another file in the repo.

2. Use Copilot Chat inside your IDE or GitHub UI with access to the entire project context to improve and simplify your implementation using that utility function.

```js
function processOrder(data) {
    // TODO: process order and return summary string
    let summary = "";
    if ("items" in data) {
        data.items.forEach(item => {
            summary += `${item.name} x ${item.qty}, `;
        });
    }
    if (!data.customer_id) {
        return "Error: Missing customer ID";
    }
    let discount;
    if ("discount" in data) {
        discount = data.discount;
    } else {
        discount = 0;
    }
    let total = data.items ? data.items.reduce((sum, item) => sum + (item.price * item.qty), 0) : 0;
    total -= discount;
    return summary + `Total: $${total}`;
}
```
