function processOrder(data) {
    // TODO: process order and return summary string
    let summary = "";
    if ("items" in data) {
        data.items.forEach(item => {
            summary += `${item.name} x ${item.qty}, `;
        });
    }
    if (!data.customer_id) {
        return "Error: Missing customer ID";
    }
    let discount;
    if ("discount" in data) {
        discount = data.discount;
    } else {
        discount = 0;
    }
    let total = data.items ? data.items.reduce((sum, item) => sum + (item.price * item.qty), 0) : 0;
    total -= discount;
    return summary + `Total: $${total}`;
}