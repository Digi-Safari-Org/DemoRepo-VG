# Copilot Prompt Guide for Lab 1.2 (JS): Refactoring with Context-Aware GitHub Copilot Chat

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the refactoring tasks in Lab 1.2 (JS). Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity.

---

## Prompts for JS Files (`main.js`, `utils.js`)

### 1. Analyze and Suggest Improvements
**Prompt:**
> Analyze this code and suggest improvements to naming, efficiency, and scalability. Assume it is part of a production enterprise backend.

### 2. Refactor Function Naming and Signatures
**Prompt:**
> Refactor `processData` function to align with our internal enterprise naming conventions and add JSDoc.

### 3. Improve Variable Names and Performance
**Prompt:**
> Rename variables like `i`, `items`, and `total` to more meaningful names. Refactor the loop for performance, using `.reduce` if possible.

### 4. Add JSDoc and Logging
**Prompt:**
> Add JSDoc and logging to all functions for better maintainability.

---

## Prompts for Legacy JS File (`script.js`)

### 1. Refactor Legacy Function
**Prompt:**
> Rewrite the `calcTotal` function to use `.reduce()` and rename it according to frontend naming standards.

### 2. Improve Variable Names and Documentation
**Prompt:**
> Update variable names to be more descriptive and add inline documentation where necessary.

---

## Cross-File Context Prompts

### 1. Project Context Prompting
**Prompt:**
> Given the current usage in `main.js`, what would be a more scalable signature and name for `processData`?

### 2. Usage Analysis
**Prompt:**
> How are functions in `utils.js` used in `main.js`? Suggest improvements for modularity and reusability.

---

## Copilot Chat in GitHub.com UI

### 1. Compare Copilot Chat Behavior
**Prompt:**
> What context does Copilot retain in the browser compared to the IDE? Is the response more or less helpful? What additional changes does it suggest?

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```javascript
// Refactor for clarity and performance
// Add JSDoc and logging
// Use enterprise naming conventions
```

---

## Tips
- Open both `main.js` and `utils.js` for best results.
- Use Copilot Chat to ask about cross-file logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---

Happy refactoring with Copilot!
