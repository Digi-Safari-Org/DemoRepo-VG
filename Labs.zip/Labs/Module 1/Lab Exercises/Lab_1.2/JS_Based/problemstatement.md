# Lab 1.2: Refactoring with Context-Aware GitHub Copilot Chat

## Objective
You're part of an enterprise dev team that maintains several legacy services. Your current task is to refactor an outdated module written in JavaScript. The code is inefficient, poorly named, and inconsistent with your enterprise-wide standards.

Refactor a legacy JS utility module by:
- Reordering functions logically
- Renaming for clarity
- Updating function signatures (JSDoc, keyword args)
- Replacing deprecated function
- Using GitHub Copilot Chat in both **IDE** and **GitHub UI**

---

### ✅ Setup
1. Open the `Lab 1.2` project in **VS Code** with Copilot Chat enabled.
2. Ensure you are authenticated with your **GitHub Enterprise** account (with Copilot access).
3. Open the `JS Based/Starter Code/` folder.

---

### Part 1: Understand and Analyze

#### In `index.js` and `utils.js`:
- Use Copilot Chat:  
  **Prompt:**  
  > “Analyze this code and suggest improvements to naming, efficiency, and scalability. Assume it is part of a production enterprise backend.”

- Review Copilot’s suggestions for:
  - Renaming functions (e.g., processData)
  - Improving function signatures
  - Adding JSDoc comments
  - Enhancing logging or error handling

---

### Part 2: Refactor the JS Module
**In `utils.js`**
**Prompt:**  
> "Refactor `processData` function to align with our internal enterprise naming conventions and add JSDoc."

**In `script.js`**
- Rename `i`, `items`, and `total` to something meaningful.
- Add JSDoc for better readability.
- Let Copilot refactor the loop for performance (e.g., use `.reduce`).

---

### Part 3: Upgrade Legacy Logic

In `script.js`, you’ll find a similar legacy pattern.

**Prompt:**  
> "Rewrite this function to use `.reduce()` and rename it per frontend naming standards."

- Refactor the `calcTotal` function using `.reduce`.
- Update variable names (e.g., `items`, `total`) with more descriptive ones.
- Add inline documentation if necessary.

---

### Part 4: Project Context Prompting

- **Open both `index.js` and `utils.js` together.**
- Use Chat to understand how functions are used across files.

**Prompt:**  
> "Given the current usage in `index.js`, what would be a more scalable signature and name for `processData`?"

---

### Try in GitHub.com UI

1. Push this starter code to a test repo on **GitHub Enterprise**.
2. Open a file on GitHub and use **Copilot Chat (in the browser)**.
3. Compare Copilot's behavior to the IDE:
   - What context does it retain?
   - Is the response more/less helpful?
   - What additional changes does it suggest?

---
