// utils.js
// Utility functions for refactoring lab
function processData(items) {
    // Dummy implementation: sum all items
    return items.reduce((acc, val) => acc + val, 0);
}

module.exports = { processData };
