// main.js
// Entry point for refactoring lab (JS version)
const { processData } = require('./utils');

// Example usage
const items = [1, 2, 3, 4];
const result = processData(items);
console.log(result);
