def process_data(items):
    # Legacy logic with poor naming and inefficient code
    processed = []
    for i in items:
        processed.append(i.upper())
    return processed
