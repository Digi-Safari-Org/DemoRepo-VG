from utils import process_data

def main():
    data = ["apple", "banana", "carrot"]
    result = process_data(data)
    print("Processed data:", result)

if __name__ == "__main__":
    main()
