# Lab 1.2: Refactoring with Context-Aware GitHub Copilot Chat

## Objective

You're part of an enterprise dev team that maintains several legacy services. Your current task is to refactor an outdated module written in both Python and JavaScript. The code is inefficient, poorly named, and inconsistent with your enterprise-wide standards.

Refactor a legacy Python utility module by:
- Reordering functions logically
- Renaming for clarity
- Updating function signatures (type hints, keyword args)
- Replacing deprecated function
- Using GitHub Copilot Chat in both **IDE** and **GitHub UI**

---

### ✅ Setup
1. Open the `Lab 1.2` project in **VS Code** with Copilot Chat enabled.
2. Ensure you are authenticated with your **GitHub Enterprise** account (with Copilot access).
3. Open the `Starter Code/` folder.

---

### Part 1: Understand and Analyze

#### In `main.py` and `utils.py`:
- Use Copilot Chat:  
  **Prompt:**  
  > “Analyze this code and suggest improvements to naming, efficiency, and scalability. Assume it is part of a production enterprise backend.”

- Use Copilot’s response to:
  - Suggest renaming `process_data`.
  - Recommend signature improvements.
  - Consider adding docstrings or logging where relevant.

---

### Part 2: Refactor the Python Module

**Prompt:**  
> "Refactor `process_data` function to align with our internal enterprise naming conventions and add type hints."

- Rename `i`, `items`, and `processed` to something meaningful.
- Add type annotations for better readability.
- Let Copilot refactor the loop for performance (e.g., list comprehensions).

---

### Part 3: Upgrade JavaScript Logic

In `scripts.js`, you’ll find a similar legacy pattern.

**Prompt:**  
> "Rewrite this function to use `reduce()` and rename it per frontend naming standards."

- Refactor the `calcTotal` function using `.reduce`.
- Update variable names (e.g., `items`, `total`) with more descriptive ones.
- Add inline documentation if necessary.

---

### Part 4: Project Context Prompting

- **Open both `main.py` and `utils.py` together.**
- Use Chat to understand how functions are used across files.

**Prompt:**  
> "Given the current usage in main.py, what would be a more scalable signature and name for `process_data`?"

---

### Try in GitHub.com UI

1. Push this starter code to a test repo on **GitHub Enterprise**.
2. Open a file on GitHub and use **Copilot Chat (in the browser)**.
3. Compare Copilot's behavior to the IDE:
   - What context does it retain?
   - Is the response more/less helpful?
   - What additional changes does it suggest?

---
