# Copilot Prompt Guide for Lab 1.3 (JS): Advanced Prompting and Refactoring in Large JavaScript Repositories

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the refactoring and modernization tasks in Lab 1.3 (JS). Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity.

---

## Prompts for Legacy Refactoring

### 1. Refactor Monolithic Functions
**Prompt:**
> Refactor the function doTask() in `legacy/hr_workflow.js` to follow JavaScript naming standards. Split it into smaller functions and move reusable logic to `utils/common_functions.js`.

### 2. Modernize Code with JavaScript Features
**Prompt:**
> Replace loops with array methods (map, filter, reduce), add JSDoc comments, and wrap critical sections in try-catch blocks with detailed error messages. Apply changes to `common_functions.js` and `main.js`.

### 3. Upgrade Data Loading Functions
**Prompt:**
> Split `loadEmployeeData()` in `data_loader.js` into `loadCsvFile()` and `loadJsonFile()` with proper JSDoc comments. Update references in `main.js`.

---

## Cross-File Context Prompts

### 1. Modular Structure Suggestions
**Prompt:**
> This function in `main.js` depends on logic in `utils/common_functions.js` and `legacy/hr_workflow.js`. Suggest a better modular structure based on related functionality.

### 2. Naming and Documentation Improvements
**Prompt:**
> Suggest improved function names and add JSDoc comments for all major functions in this module.

---

## Copilot Chat in GitHub.com UI

### 1. Summarize and Suggest Improvements
**Prompt:**
> Summarize this module and suggest improved function names and modular structure. What are the main issues and how can they be addressed?

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```javascript
// Refactor for modularity and clarity
// Add JSDoc comments
// Move reusable logic to utils/common_functions.js
// Use array methods where possible
// Add robust error handling
```

---

## Tips
- Open all files in the Starter Code folder for best results.
- Use Copilot Chat to ask about cross-file logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---
