// data_loader.js
// Loads employee data from CSV 
const fs = require('fs');
const path = require('path');

function loadEmployeeData(csvPath) {
    // Dummy implementation: returns array of employee objects
    // In real code, parse CSV and return structured data
    return [
        { id: 'EMP1001', name: 'Alice', department: 'HR' },
        { id: 'EMP1002', name: 'Bob', department: 'Finance' }
    ];
}

module.exports = { loadEmployeeData };
