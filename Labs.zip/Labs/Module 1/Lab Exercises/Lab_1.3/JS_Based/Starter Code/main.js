// main.js
// Entry point for HR automation tool 
const { loadEmployeeData } = require('./data_loader');
const { processEmployeeData } = require('./utils/common_functions');
const { runLegacyWorkflow } = require('./legacy/hr_workflow');

// Example usage
const employees = loadEmployeeData('employees.csv');
const processed = processEmployeeData(employees);
runLegacyWorkflow(processed);
