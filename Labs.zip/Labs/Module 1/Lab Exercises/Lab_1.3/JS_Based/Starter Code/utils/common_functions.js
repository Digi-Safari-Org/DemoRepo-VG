// common_functions.js
// Utility functions for HR automation 
function processEmployeeData(employees) {
    // Dummy implementation: add processed flag
    return employees.map(emp => ({ ...emp, processed: true }));
}

module.exports = { processEmployeeData };
