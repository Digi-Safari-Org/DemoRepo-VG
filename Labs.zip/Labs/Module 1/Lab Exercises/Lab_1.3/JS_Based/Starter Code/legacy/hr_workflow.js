// hr_workflow.js
// Legacy workflow logic 
function runLegacyWorkflow(employees) {
    // Dummy implementation: print employee IDs
    employees.forEach(emp => {
        console.log(`Processing legacy workflow for ${emp.id}`);
    });
}

module.exports = { runLegacyWorkflow };
