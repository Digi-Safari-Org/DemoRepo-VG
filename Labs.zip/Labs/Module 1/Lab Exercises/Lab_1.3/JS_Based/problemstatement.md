# Lab 1.3 (JS): Advanced Prompting and Refactoring in Large JavaScript Repositories with GitHub Copilot Enterprise

## Scenario
You are a developer on a large enterprise engineering team. Your team has inherited a legacy JavaScript codebase named internal-hr-automation-tool-js, originally written by multiple developers over several years.

This system handles HR workflows such as:
- Loading and processing employee data from CSV sources
- Generating reports
- Sending notifications to other departments

**However, the code suffers from:**
- Poor function and variable naming (doTask(), getData())
- Long, monolithic functions with unclear responsibilities
- Hardcoded logic scattered across files
- Missing JSDoc comments, documentation, and testing
- No modular design, making reuse and maintenance difficult

## Overview
This lab is designed for JavaScript developers using GitHub Copilot Enterprise to modernize legacy codebases. You’ll simulate working in a large internal repository, practice crafting contextual prompts, and use Copilot Chat in both the IDE and GitHub UI to refactor code with enterprise-grade context.

### Lab Objectives
By the end of this lab, you will:
- Use context-aware prompts to work across multiple files
- Practice language-specific prompt writing for JavaScript
- Refactor code using Copilot Chat in both the GitHub UI and IDE
- Upgrade function signatures, naming conventions, and modularization
- Explore the power of Copilot Enterprise indexing for project-wide understanding

**Your Role:**
You’ve been tasked with refactoring this codebase to modern JavaScript standards using GitHub Copilot Enterprise.

**You’ll use:**
- Copilot Chat in IDE for inline and full-file refactoring
- Copilot Chat in GitHub UI to review, summarize, and suggest high-level improvements

```
Starter Code/
├── index.js
├── data_loader.js
├── utils/
│   └── common_functions.js
└── legacy/
    └── hr_workflow.js
```

### Lab Tasks
1. **Part 1: Explore the Legacy Repo**
    - Open all files listed above.
    - Review inconsistent naming and unstructured logic.

2. **Part 2: Refactor with Contextual Prompting**
    - **File**: legacy/hr_workflow.js

    **Prompt Copilot in IDE Chat:**
    ```
    Refactor the function doTask() to follow JavaScript naming standards. Split it into smaller functions and move reusable logic to utils/common_functions.js.
    ```

3. **Part 3: JavaScript Prompting Techniques**

    **Prompt Copilot:**
    ```
    Replace loops with array methods (map, filter, reduce), add JSDoc comments, and wrap critical sections in try-catch with detailed error messages.
    ```
    Apply changes to `common_functions.js` and `index.js`.

4. **Part 4: Code Reordering and Signature Upgrades**
    - **File**: `data_loader.js`

    **Prompt:**
    ```
    Split `loadEmployeeData()` into `loadCsvFile()` and `loadJsonFile()` with proper JSDoc comments. Update references in `index.js`.
    ```
5. **Part 5: Copilot Chat in GitHub UI vs IDE**
    - Use this prompt in both environments:
    - Summarize this module and suggest improved function names and modular structure.

6. **Part 6: Using Enterprise Context Across Files**
    **Prompt in IDE:**
    ```
    This function in index.js depends on logic in utils/common_functions.js and hr_workflow.js. Suggest a better modular structure based on related functionality.
    ```

**Copilot should:**
- Analyze all three files
- Recommend structure improvements
- Suggest or generate reusable service functions


```
## Issues to be Fixed by Learners

### **`legacy/hr_workflow.js`**
- Function `doTask()` has:
  - Poor naming (`x`, `e`)
  - Multiple responsibilities (filtering, logging, counting) in a single function
  - Manual loops instead of `.filter()` or `.length`
  - No JSDoc comments

### **`utils/common_functions.js`**
- `processEmployeeData()`:
  - Uses a manual `for` loop instead of `.map()`
  - Modifies objects in place instead of returning new objects
  - Missing JSDoc comments

### **`data_loader.js`**
- `loadEmployeeData()`:
  - Single large function handling multiple tasks (reading file + parsing CSV)
  - Uses synchronous file reads
  - Parsing logic is not reusable
  - Needs splitting into `loadCsvFile()` and `loadJsonFile()` functions with JSDoc

### **`index.js`**
- Calls outdated function names after refactor
- Lacks error handling
- No JSDoc or inline documentation
```