def format_employee_record(record):
    return f"{record['name']} ({record['id']}) - {record['department']}"

#  Copilot Prompt:
# "Add type annotations and improve function naming where needed."
# "Write unittests for these utility functions in a new test_utils.py file."

def send_email(recipient, subject, body):
    print(f"Sending email to {recipient} with subject '{subject}'")
    # Dummy implementation
