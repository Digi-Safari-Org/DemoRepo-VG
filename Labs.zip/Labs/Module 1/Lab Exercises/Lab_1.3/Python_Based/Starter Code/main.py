from data_loader import load
from legacy.hr_workflow import doTask

# Copilot Prompt:
# "Can you summarize what this main script does?"
# "Suggest improvements to make this entrypoint more modular and readable."

if __name__ == "__main__":
    data = load("employees.csv")
    doTask(data)
