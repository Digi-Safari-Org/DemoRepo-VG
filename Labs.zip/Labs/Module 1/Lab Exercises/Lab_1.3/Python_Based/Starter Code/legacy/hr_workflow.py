from utils.common_functions import format_employee_record, send_email

# Copilot Prompt:
# "Refactor this legacy function into smaller, reusable functions."
# "Suggest better naming for 'doTask' based on what it does."
# "Move any reusable logic to utils/common_functions.py."

def doTask(data):
    for record in data:
        formatted = format_employee_record(record)
        print("Processing:", formatted)
        if record.get("send_notification", "no") == "yes":
            send_email(record["email"], "HR Notification", "Your data was processed.")
