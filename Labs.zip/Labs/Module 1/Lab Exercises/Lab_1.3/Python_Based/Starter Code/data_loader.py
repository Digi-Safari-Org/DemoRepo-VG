import csv
import json

# Copilot Prompt:
# "Refactor the 'load' function into two separate functions: one for loading CSV and one for JSON."
# "Add type hints and meaningful docstrings to all functions."


def load(file_path, file_type="csv"):
    if file_type == "csv":
        with open(file_path, newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            return [row for row in reader]
    elif file_type == "json":
        with open(file_path) as jsonfile:
            return json.load(jsonfile)
    else:
        raise ValueError("Unsupported file type")
