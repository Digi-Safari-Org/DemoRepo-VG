# Lab 1.3: Advanced Prompting and Refactoring in Large Python Repositories with GitHub Copilot Enterprise 

## Scenario: 
You are a developer on a large enterprise engineering team. Your team has inherited a legacy Python codebase named internal-hr-automation-tool, originally written by multiple developers over several years.

This system handles HR workflows such as:

- Loading and processing employee data from CSV and JSON sources
- Generating reports
- Sending notifications to other departments

**However, the code suffers from:**

- Poor function and variable naming (doTask(), getData())
- Long, monolithic functions with unclear responsibilities
- Hardcoded logic scattered across files
- Missing type hints, documentation, and testing
- No modular design, making reuse and maintenance difficult

## Overview
This lab is designed for the developers using GitHub Copilot Enterprise to modernize legacy codebases. You’ll simulate working in a large internal repository, practice crafting contextual prompts, and use Copilot Chat in both the IDE and GitHub UI to refactor code with enterprise-grade context.

#### Lab Objectives
By the end of this lab, you will:

- Use context-aware prompts to work across multiple files
- Practice language-specific prompt writing for Python
- Refactor code using Copilot Chat in both the GitHub UI and IDE
- Upgrade function signatures, naming conventions, and modularization
- Explore the power of Copilot Enterprise indexing for project-wide understanding

**Your Role:**
You’ve been tasked with refactoring this codebase to modern Python standards using GitHub Copilot Enterprise.

**You’ll use:**

- Copilot Chat in IDE for inline and full-file refactoring
- Copilot Chat in GitHub UI to review, summarize, and suggest high-level improvements

```
Starter Code/
├── main.py
├── data_loader.py
├── utils/
│   └── common_functions.py
└── legacy/
    └── hr_workflow.py
```

### Lab Tasks
1. **Part 1: Explore the Legacy Repo**
    - Open all files listed above.
    - Review inconsistent naming and unstructured logic.

    **Use Copilot Chat:**
    **Prompt:**
    ```
    “Analyze this code and suggest improvements to naming, efficiency, and scalability. Assume it is part of a production enterprise backend.”
    ```

#### Review Copilot’s suggestions for:
- Renaming functions and variables for clarity and consistency
- Improving function signatures with type hints and docstrings
- Enhancing error handling with try-except blocks
- Modularizing code for better reuse

2. **Part 2: Refactor with Contextual Prompting**
    - **File**: legacy/hr_workflow.py

    **Prompt Copilot in IDE Chat:**
    ```
    Refactor the function doTask() to follow Python naming standards. Split it into smaller functions and move reusable logic to utils/common_functions.py.
    ```

3. **Part 3: Pythonic Prompting Techniques**
    **In data_loader.py and utils/common_functions.py**
    
    **Prompt Copilot:**
    ```
    Replace loops with list comprehensions, add type hints, and wrap critical sections in try-except with detailed error messages. Split monolithic functions into smaller, reusable ones and update references in other files.
    ```

4. **Part 4: Code Reordering and Signature Upgrades**
    - **File**: data_loader.py

    **Prompt:**
    ```
    Split load() into **load_json_file()** and **load_csv_file()** with proper type hints and docstrings. Update references in main.py.
    ```
5. **Part 5: Copilot Chat in GitHub UI vs IDE**
    - Use this prompt in both environments:
    - Summarize this module and suggest improved function names and modular structure.

6. **Part 6: Using Enterprise Context Across Files**
    **Prompt in IDE:**
    ```
    This function in `main.py` depends on logic in `utils/common_functions.py` and `hr_workflow.py`. Suggest a better modular structure based on related functionality.
    ```

**Copilot should:**

- Analyze all three files
- Recommend structure improvements
- Suggest or generate reusable service functions