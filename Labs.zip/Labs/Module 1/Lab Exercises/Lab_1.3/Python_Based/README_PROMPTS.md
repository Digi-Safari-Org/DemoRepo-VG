# 🧠 GitHub Copilot Prompt Guide

This file includes suggested prompts to use with GitHub Copilot Enterprise for refactoring, improving, and exploring the starter project.

---

## 🔹 main.py

```python
# Prompt:
# "Can you summarize what this main script does?"
# "Suggest improvements to make this entrypoint more modular and readable."
```

---

## 🔹 data_loader.py

```python
# Prompt:
# "Refactor the 'load' function into two separate functions: one for loading CSV and one for JSON."
# "Add type hints and meaningful docstrings to all functions."
# "Rewrite the exception handling to give more informative error messages."
```

---

## 🔹 utils/common_functions.py

```python
# Prompt:
# "Add type annotations and improve function naming where needed."
# "Write unittests for these utility functions in a new test_utils.py file."
# "Replace print statements with a proper logging mechanism."
```

---

## 🔹 legacy/hr_workflow.py

```python
# Prompt:
# "Refactor this legacy function into smaller, reusable functions."
# "Suggest better naming for 'doTask' based on what it does."
# "Move any reusable logic to utils/common_functions.py."
# "Is this function too long? How can I make it more modular and testable?"
```