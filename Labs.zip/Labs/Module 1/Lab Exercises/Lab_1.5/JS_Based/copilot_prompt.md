# Copilot Prompts and Lab Steps for Module 1 (JavaScript)

## Lab 1.5: Enforcing Enterprise Naming Conventions and Using Copilot Chat Agents

**Copilot Prompt:**
```
You have a JavaScript module with inconsistent variable and function names (e.g., itm, qtyOrdered, calcPrice). Use Copilot Chat to:
1. Rename all variables and functions to follow enterprise naming conventions (camelCase, descriptive names).
2. Add JSDoc comments to all functions, including parameter and return types.
3. Update all references to renamed functions/variables across the file and related modules.
4. Ensure all names are self-explanatory and consistent with enterprise standards.
```

**Steps to Complete:**
1. Open `Lab_1.5/main.js` and review the code for inconsistent naming.
2. Use Copilot Chat to rename variables and functions to camelCase and descriptive names.
3. Add JSDoc-compliant comments to all functions.
4. If functions interact with other modules, use Copilot Chat with project context to update all references.
5. Test the updated code to ensure all names and references are correct.
