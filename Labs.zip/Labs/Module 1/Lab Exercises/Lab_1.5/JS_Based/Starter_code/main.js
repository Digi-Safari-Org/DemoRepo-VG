function calcPrice(itm, qtyOrdered) {
    const price = itm.p;
    const totalPrice = price * qtyOrdered;
    return totalPrice;
}

function process(itmList) {
    let totalCost = 0;
    for (const itm of itmList) {
        totalCost += calcPrice(itm, itm.qty);
    }
    return totalCost;
}