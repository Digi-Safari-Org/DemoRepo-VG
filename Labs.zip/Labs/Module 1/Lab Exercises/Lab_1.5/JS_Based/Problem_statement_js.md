# Lab 1.5: Enforcing Enterprise Naming Conventions and Using Copilot Chat Agents for Large Project Context

### Objectives
    - Learn to write prompts that enforce enterprise naming conventions.

    - Use Copilot Chat to rename variables and functions across a file/project consistently.

    - Practice creating descriptive, standard-compliant function names and JSDoc comments.

    - Understand differences in Copilot Chat usage in GitHub UI vs IDE with large repo context.

### Instructions
Part 1: Rename Variables and Functions for Consistency
1. You have a JavaScript module with inconsistent variable names (e.g., itm, qtyOrdered, calcPrice) that violate your enterprise naming standards (camelCase, descriptive names).

2. Use Copilot Chat with a detailed prompt to rename variables and functions consistently across the file.

3. Verify that renamed variables follow camelCase and are self-explanatory.

Part 2: Standardize Function Names and Add JSDoc Comments
1. Your functions currently lack proper names and JSDoc comments.

2. Ask Copilot Chat to rename ambiguous functions to enterprise-standard descriptive names and add JSDoc comments including parameter and return types.

Part 3: Using Copilot Chat Agent with Multi-File Context
1. The functions interact with other modules in the repo.

2. Use Copilot Chat in the IDE or GitHub UI where it has full project context to update references to renamed functions/variables across files.

3. Observe how suggestions vary based on environment and context availability.


```Js
function calcPrice(itm, qtyOrdered) {
    const price = itm.p;
    const totalPrice = price * qtyOrdered;
    return totalPrice;
}

function process(itmList) {
    let totalCost = 0;
    for (const itm of itmList) {
        totalCost += calcPrice(itm, itm.qty);
    }
    return totalCost;
}

```