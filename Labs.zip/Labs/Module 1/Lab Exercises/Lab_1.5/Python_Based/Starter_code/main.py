def calcPrice(itm, qtyOrdered):
    price = itm["p"]
    totalPrice = price * qtyOrdered
    return totalPrice

def process(itmList):
    totalCost = 0
    for itm in itmList:
        totalCost += calcPrice(itm, itm["qty"])
    return totalCost