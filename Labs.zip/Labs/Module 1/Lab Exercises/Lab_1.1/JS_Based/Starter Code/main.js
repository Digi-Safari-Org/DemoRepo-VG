// main.js
// Entry point for leave management 
const { calculateRemainingLeave } = require('./leave_management');

// Example usage
const remaining = calculateRemainingLeave('EMP1001');
console.log(`Remaining leave for EMP1001: ${remaining}`);
