// leave_management.js
// Calculates remaining leave for an employee 
const { getEmployeeLeaveRecord } = require('./employee_data');

function calculateRemainingLeave(employeeId) {
    const record = getEmployeeLeaveRecord(employeeId);
    if (!record) return null;
    // Calculate remaining leave
    return record.total + record.carry_over - record.taken;
}

module.exports = { calculateRemainingLeave };
