# Lab 1.1 (JS): Using Copilot Context with Internal Repos

## Scenario
You are contributing to a large internal HRMS (Human Resource Management System) codebase hosted on your GitHub Enterprise instance. The repository spans multiple modules, with shared business logic scattered across files.

Your task is to complete missing leave calculation logic in `leave_management.js` by using Copilot’s context awareness to reference functions defined elsewhere in the repo.
---

## ✅ Tasks

Use Copilot to:
1. Open `leave_management.js` and complete the `calculateRemainingLeave()` function.
2. Ensure your logic references `getEmployeeLeaveRecord()` from `employee_data.js`rather than duplicating data retrieval logic.
3. **Use both:**
    - Inline suggestions (while coding)
    - Copilot Chat with file/project context to guide your implementation.
4. Test it with a sample employee ID (`"EMP1001"`).
5. If Copilot’s initial implementation omits carry_over leave, extend the logic to include it by prompting Copilot again.

---

## Expected Goal

```
calculateRemainingLeave("EMP1001")  // ➞ 16 (25 total + 3 carry over - 12 taken)
```

#### Try with these Prompts:
1. **Inline**: “Use getEmployeeLeaveRecord() from employee_data.js to calculate remaining leave including carry_over.”
2. **Chat**: @copilot, analyze leave_management.js and employee_data.js, and fill in the missing logic in calculateRemainingLeave() following existing patterns.
