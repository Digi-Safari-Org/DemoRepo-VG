# Lab 1.1 - Using Copilot Context with Internal Repos

## Scenario
You are working in a large internal HRMS repo. Your goal is to use GitHub Copilot’s context awareness to implement missing logic in `leave_management.py`.

---

## ✅ Tasks

Use Copilot to:
1. Open `leave_management.py` and complete the `calculate_remaining_leave()` function.
2. Ensure your logic references `get_employee_leave_record()` from `employee_data.py` rather than duplicating data retrieval logic..
3. **Use both:**
    - Inline suggestions (while coding)
    - Copilot Chat with file/project context to guide your implementation.
4. Test it with a sample employee ID (`"EMP1001"`).
5. If Copilot’s initial implementation omits carry_over leave, extend the logic to include it by prompting Copilot again.

---

## ✨ Goal

```
calculate_remaining_leave("EMP1001")  # ➞ 16 (25 total + 3 carry over - 12 taken)
```

#### Try with these:
1. calculate remaining leave using total, taken, and carry_over
2. Use chat: @copilot, explain what’s missing in this function or fill in the function using other file's context