# employee_data.py

def get_employee_leave_record(employee_id):
    # Normally this would come from DB; simulating data here
    return {
        "total_leave": 25,
        "leave_taken": 12,
        "carry_over": 3
    }
