# Copilot Prompt and Lab Steps for Module 5 (Python)

## Copilot Prompt
```
# Refactor legacy data client code to use ModernDataSDK and enterprise_utils helpers.
# 1. Review legacy_data_client.py: legacy_authenticate() returns a token, legacy_fetch_data(id) returns flat dicts, with manual parsing/validation.
# 2. Use Copilot Enterprise to discover and import validate_response, extract_data_field, and other helpers from enterprise_utils.
# 3. Refactor to ModernDataSDK: use login() for session_id, fetch_data(payload) for nested responses.
# 4. Replace manual validation with validate_response(), and use extract_data_field() for data extraction.
# 5. Maintain enterprise naming conventions and add typing annotations where appropriate.
# 6. Add robust error handling and use Python's logging module for failures.
# 7. Output from the modern client must remain backward-compatible with the legacy client for integration safety.
# 8. Write test cases to verify login, data fetch, error handling, and utility usage.
```

---

## Detailed Steps to Complete the Lab

1. Open or create `legacy_data_client.py` and implement sample legacy client usage:
   - `legacy_authenticate()` returns a token string.
   - `legacy_fetch_data(id)` returns flat dictionaries, with manual inline parsing and validation.
2. Explore or simulate the `enterprise_utils` repo/module:
   - Use `validate_response(data: dict) -> bool` to check responses.
   - Use `extract_data_field(data: dict, field: str) -> Any` to extract values.
   - Use any other provided helpers for request formatting.
3. Refactor the legacy client code to use `ModernDataSDK`:
   - Use `login()` to get a session_id.
   - Use `fetch_data(payload: dict)` to get nested response objects.
   - Replace manual validation with `validate_response()`.
   - Use `extract_data_field()` for field extraction.
4. Ensure all code follows enterprise naming conventions and includes typing annotations where appropriate.
5. Add robust error handling for failed login, missing fields, etc., and use Python's logging module for failures.
6. Output from the modern client must remain backward-compatible with the legacy client for integration safety.
7. Write test cases to verify successful login, data fetch, error handling, and correct use of utilities.
