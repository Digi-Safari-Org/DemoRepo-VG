# Copilot Prompt and Lab Steps for Module 5.1

## Copilot Prompt
```
// Refactor legacy client API usage to use ModernDataSDK and enterprise_utils helpers.
// 1. Review legacy_data_client.js: legacyAuthenticate() returns a token, legacyFetchData(id) returns flat JSON, with manual parsing/validation.
// 2. Use Copilot Enterprise to discover and import validateResponse, extractDataField, and other helpers from enterprise_utils.
// 3. Refactor to ModernDataSDK: use login() for sessionId, fetchData(payload) for nested responses.
// 4. Replace manual validation with validateResponse(), and use extractDataField() for data extraction.
// 5. Maintain enterprise naming conventions, add JSDoc/type annotations, and ensure output is backward-compatible with the legacy client.
```

---

## Detailed Steps to Complete the Lab

1. Open or create `src/legacy_data_client.js` and implement sample legacy client usage:
   - `legacyAuthenticate()` returns a token string.
   - `legacyFetchData(id)` returns flat JSON objects, with manual inline parsing and validation.
2. Explore or simulate the `enterprise_utils` repo/module:
   - Use `validateResponse(data)` to check responses.
   - Use `extractDataField(data, field)` to extract values.
   - Use any other provided helpers for request formatting.
3. Refactor the legacy client code to use `ModernDataSDK`:
   - Use `login()` to get a sessionId.
   - Use `fetchData(payload)` to get nested response objects.
   - Replace manual validation with `validateResponse()`.
   - Use `extractDataField()` for field extraction.
4. Ensure all code follows enterprise naming conventions and includes JSDoc/type annotations.
5. Output from the modern client must remain backward-compatible with the legacy client for integration safety.
