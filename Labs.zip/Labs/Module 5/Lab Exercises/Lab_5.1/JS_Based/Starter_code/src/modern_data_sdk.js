// In src/modern_data_sdk.js, implement a tiny class ModernDataSDK 
