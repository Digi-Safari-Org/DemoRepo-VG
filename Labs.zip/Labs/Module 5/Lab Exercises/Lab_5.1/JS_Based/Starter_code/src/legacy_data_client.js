// Create src/legacy_data_client.js that simulates the legacy procedural client.
