/**
 * @file Minimal structured logger for enterprise-style logs.
 */
function stamp(level, payload) {
  return JSON.stringify({
    level,
    time: new Date().toISOString(),
    ...payload
  });
}

module.exports = {
  info: (obj) => console.log(stamp('INFO', obj)),
  error: (obj) => console.error(stamp('ERROR', obj))
};
