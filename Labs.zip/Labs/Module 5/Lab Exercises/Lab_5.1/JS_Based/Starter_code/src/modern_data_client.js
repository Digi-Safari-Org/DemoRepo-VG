// Create a class called ModernClient that wraps the ModernDataSDK to provide a legacy-compatible output.

