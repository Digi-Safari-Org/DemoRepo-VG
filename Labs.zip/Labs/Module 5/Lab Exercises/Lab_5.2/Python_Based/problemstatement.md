# Lab 5.2 : CI/CD, Refactoring, and Testing for Python Projects

## Objective
You're part of an enterprise dev team maintaining a Python service. Your task is to refactor, test, and automate the project using Copilot Enterprise features, while also ensuring version-aware upgrades, pull request validation, and compliance through audit logs.

Refactor a legacy Python module by:
- Improving function signatures and modularity
- Adding type hints and docstrings
- Expanding test coverage
- Setting up CI/CD with GitHub Actions
- Using Copilot Chat in both **IDE** and **GitHub UI**
- Applying version-aware prompting to handle framework/dependency upgrades
- Validating pull requests with Copilot-assisted review
- Reviewing enterprise audit logs for compliance

---

### ✅ Setup
1. Open the `Lab 5.1` project in **VS Code** with Copilot Chat enabled.
2. Ensure you are authenticated with your **GitHub Enterprise** account (with Copilot access).
3. Open the `Python Based/Starter Code/` folder.

---

### Part 1: Refactor and Improve Code
- Use Copilot Chat:
  > "Analyze this code and suggest improvements for modularity, readability, and maintainability."
- Refactor `add_numbers` to use type hints and add a docstring.
- Add logging to `app.py`.

---

### Part 2: Expand and Improve Tests
- Use Copilot Chat:
  > "Review the tests for coverage and reliability. Add new tests for edge cases and error scenarios."
- Add more tests to `test_app.py`.

---

### Part 3: Set Up CI/CD
- Review `.github/workflows/ci.yml`.
- Use Copilot Chat:
  > "Suggest improvements for automation, reliability, and security in this workflow."
- Ensure tests run on every push and pull request.

---

### Part 4: Update Changelog and Requirements
- Use Copilot Chat:
  > "Update CHANGELOG.md to reflect recent changes."
  > "Review requirements.txt and update dependencies."

- Use version-aware prompting:

  > "What changes are required if upgrading Python 3.9 → 3.11?"
  > "Suggest migration steps if moving from Flask 1.x to Flask 2.x."

#### Part 5: Pull Request Validation 

- Push your changes to a new branch and open a Pull Request.
- In the PR conversation, use Copilot Chat:
  > "Review this PR for potential issues and suggest improvements."

- Validate that the CI/CD pipeline runs on the PR and blocks merging if tests fail.

#### Part 6: Audit Logs 

- Open your GitHub Enterprise organization settings.
- Navigate to Audit Logs and filter for your lab repository.
- Check logs for:

  - Who pushed changes
  - Who opened/approved the PR
  - Copilot activity (if available in your enterprise plan)


---

### Try in GitHub.com UI
- Push this starter code to a test repo on **GitHub Enterprise**.
- Open a file on GitHub and use **Copilot Chat (in the browser)**.
- Compare Copilot's behavior to the IDE:
  - What context does it retain?
  - Is the response more/less helpful?
  - What additional changes does it suggest?

---
