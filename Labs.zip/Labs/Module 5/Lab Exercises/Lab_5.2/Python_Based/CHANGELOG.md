
# CHANGELOG

## [Unreleased]
- Initial Python lab structure created
- Added utility functions (add, divide, compound interest)
- Added app.py with logging
- Basic test scaffold added
- CI workflow created (pytest only)
