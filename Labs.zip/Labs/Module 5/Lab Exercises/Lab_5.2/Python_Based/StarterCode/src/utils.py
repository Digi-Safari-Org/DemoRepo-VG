# utils.py (starter code)

def add_numbers(a, b):
    # Just adds values, no validation
    return a + b

def divide_numbers(a, b):
    # No error handling, division by zero will crash
    return a / b

def calculate_compound_interest(principal, rate, time):
    # Compound interest formula: A = P(1 + r/100)^t
    # But here no input validation, no docstring
    return principal * ((1 + rate/100) ** time)
