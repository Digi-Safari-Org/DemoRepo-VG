# app.py (starter code)

from utils import add_numbers, divide_numbers, calculate_compound_interest

def main():
    result_add = add_numbers(2, 3)
    print("Addition result:", result_add)

    result_div = divide_numbers(10, 0)  # Intentional bug: division by zero
    print("Division result:", result_div)

    interest = calculate_compound_interest(1000, 5, 2)
    print("Compound interest:", interest)

if __name__ == "__main__":
    main()
