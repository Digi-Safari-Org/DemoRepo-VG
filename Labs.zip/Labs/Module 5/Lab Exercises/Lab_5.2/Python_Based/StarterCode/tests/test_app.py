
import pytest
from utils import add_numbers

def test_add_numbers_valid():
    assert add_numbers(2, 3) == 5

# TODO(@kb test_template_pytest):
# - Add tests for divide_numbers (valid + division by zero)
# - Add tests for calculate_compound_interest (valid + invalid inputs)
# - Add parametrized tests for multiple scenarios


# test_app.py (starter code)

import unittest
from utils import add_numbers, divide_numbers, calculate_compound_interest

class TestUtils(unittest.TestCase):

    def test_add_numbers(self):
        self.assertEqual(add_numbers(2, 3), 5)

    def test_divide_numbers(self):
        # Only tests a normal case, no edge cases
        self.assertEqual(divide_numbers(10, 2), 5)

    def test_calculate_compound_interest(self):
        # Simple compound interest check
        self.assertAlmostEqual(calculate_compound_interest(1000, 5, 2), 1102.5)

if __name__ == "__main__":
    unittest.main()
