# Lab 5.2 – Version-Aware Modernization with PR Validation & Audit Logs

## Objective
In this lab, you will:

1. Suggest and apply **SDK/API** upgrades using Copilot and version history.
2. Refactor legacy code (getData) to modern **SDK** methods (fetchDataAsync).
3. Use Enterprise **KB** and **cross-repo references** to reuse upgrade patterns.
4. Apply version-aware prompting with CHANGELOG.md as context.
5. Validate modernization through **Pull Requests (PRs)** and **Enterprise audit logs.**
---
### Scenario

You are part of the platform engineering team responsible for modernizing a legacy service.
The codebase currently:
- Wraps the deprecated SDK v2.5.0 method getData in utils.js.
- Uses this wrapper in app.js, which logs SDK v2.5.0 usage.
- The CHANGELOG.md shows that getData was removed in v3.0.0, replaced with fetchDataAsync.

**Your task:**
- Upgrade the service to SDK v3.0.0.
- Remove legacy callback-based wrappers and adopt async/await.
- Ensure modernization aligns with enterprise KB standards and patterns already used in other repos.
- Validate all changes through **PR reviews** and **audit logs**.

#### Prerequisites
- GitHub Enterprise account with **Copilot Enterprise** enabled.
- Access to Enterprise Knowledge Base (KB) for modernization patterns.
- Node.js 18+ installed locally.
- **NOTE:** A pre-built .github/workflows/ci.yml is provided to run tests automatically.
- Access to GitHub Enterprise audit logs (via Settings → Audit Log).

---

## Lab Steps

### **Step 1 – Review Version History**
1. Open `CHANGELOG.md` and review past API/SDK changes.
2. Use a **version-aware Copilot prompt** in the chat panel:
   ```
   Review the CHANGELOG.md and suggest the safest upgrade path for updating the SDK from v2.5.0 to the latest stable version, ensuring backward compatibility.
   ```

---

### **Step 2 – Apply Modernization Changes**
1. Open `src/app.js` and `src/utils.js`.
2. Replace deprecated SDK calls based on Copilot’s recommendations.
3. Ensure your changes align with patterns in the latest version shown in the changelog.
4. Use Copilot Chat with version-aware prompting:
   ```
   Refactor fetchData to use fetchDataAsync instead of getData, based on CHANGELOG.md (v3.0.0). 
   ```
---

### Step 3 – Reuse Patterns from Enterprise KB & Other Repos

- Use Copilot with KB search:
   ```
   @kb search "async/await migration examples for fetchDataAsync"
   ```
- If other repos already upgraded, reuse their modernization patterns.


### **Step 4 – Create a Feature Branch**
```
git checkout -b feature/sdk-upgrade
```
Commit your modernization changes:
```
git add .
git commit -m "Modernize SDK calls from v2.5.0 to latest"
```
Push your branch:
```
git push origin feature/sdk-upgrade
```

---

### **Step 4 – Open a Pull Request**
1. Go to GitHub and create a PR from `feature/sdk-upgrade` into `main`.
2. GitHub Actions (`.github/workflows/ci.yml`) will run automated tests.
3. In PR view, ask Copilot:
   ```
   Review this PR for modernization compliance with enterprise KB. Are there any missed deprecations or code smells?
   ```

---

### **Step 5 – Validate via Audit Logs**
- Go to GitHub Enterprise → Audit Logs.

**Search for copilot.**

### Confirm:

- Who used Copilot.
- Which suggestions were accepted/rejected.
- That modernization followed enterprise policies.
  
(Note: Only users with admin access can create policies)

---

### **Step 6 – Verify in Audit Logs**
1. Navigate to your organization’s settings → **Audit Log**.
2. Search for:
   ```
   sdk-upgrade
   pull_request
   ```
3. Confirm:
   - PR creation is logged.
   - Code changes are linked to your branch.
   - Merge event is recorded.

---

## Expected Outcomes

- Deprecated getData fully removed.
- Modernized code uses fetchDataAsync with async/await.
- Enterprise KB patterns reused instead of reinvented.
- Cross-repo consistency achieved via Copilot Enterprise indexing.
- PR-reviewed modernization documented in audit logs.

---

## Bonus Task
- Try asking Copilot to **write a migration guide** based on your changes.
- Include that guide in the PR description for better team onboarding.
