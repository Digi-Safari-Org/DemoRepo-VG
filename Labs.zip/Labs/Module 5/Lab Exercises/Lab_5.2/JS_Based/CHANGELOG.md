# Changelog

## [3.0.0] - 2024-06-15
### Changed
- Replaced `getData` with `fetchDataAsync` (Promise-based).
- Improved error handling.
- Added support for async/await syntax.

## [2.5.0] - 2022-04-10
### Deprecated
- `getData` method now marked as deprecated, will be removed in v3.0.0.

## [2.0.0] - 2020-03-05
### Added
- Introduced `getData` method.
