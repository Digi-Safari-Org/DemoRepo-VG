# Copilot Prompt Guide for Lab 5.2: CI/CD, Refactoring, and Testing for Node.js Projects

## Overview
This guide provides practical prompts for using GitHub Copilot Chat and inline suggestions to complete the CI/CD, refactoring, and testing tasks in Lab 5.1. Use these prompts in the Copilot Chat sidebar or as inline comments to maximize Copilot’s context awareness and productivity for Node.js projects.

---

## Prompts for Refactoring and Improving Code (`src/app.js`, `src/utils.js`)

### 1. Analyze and Suggest Improvements
**Prompt:**
> Analyze `app.js` and `utils.js` for code quality, modularity, and maintainability. Suggest improvements and refactor for best practices.

### 2. Refactor for Clarity and Performance
**Prompt:**
> Refactor functions for clarity, reliability, and performance. Add JSDoc comments to all functions.

### 3. Apply Team Standards
**Prompt:**
> Apply our team's coding and testing standards to all code in this project. What changes are needed?

---

## Prompts for Testing (`tests/app.test.js`)

### 1. Review and Expand Tests
**Prompt:**
> Review the tests for coverage and reliability. Add new tests for edge cases and error scenarios.

### 2. Fix and Modernize Test Logic
**Prompt:**
> Refactor any outdated or flaky test logic. Ensure all tests are deterministic and robust.

---

## Prompts for CI/CD Workflow (`.github/workflows/ci.yml`)

### 1. Review and Improve Workflow
**Prompt:**
> Review the CI workflow in `ci.yml` and suggest improvements for automation, reliability, and security.

### 2. Integrate Tests and Linting
**Prompt:**
> Update the workflow to run tests and linting on every push and pull request. Ensure failures block merges.

---

## Prompts for Changelog and Package Management (`CHANGELOG.md`, `package.json`)

### 1. Update Changelog
**Prompt:**
> Review `CHANGELOG.md` and update it to reflect recent changes and improvements.

### 2. Update Dependencies
**Prompt:**
> Review `package.json` and update dependencies to the latest compatible versions. Remove unused or deprecated packages.

---

## Cross-File Context Prompts

### 1. Usage Analysis and Modularization
**Prompt:**
> How do changes in `app.js` and `utils.js` affect the tests and CI workflow? Suggest improvements for modularity and maintainability across files.

### 2. Apply Team Standards
**Prompt:**
> Apply our team's CI/CD, coding, and testing standards to all code in this project. What changes are needed?

---

## Inline Comment Prompts

Add these as comments in your code to guide Copilot:
```javascript
// Refactor for clarity and modularity
// Add JSDoc comments
// Expand tests for edge cases
// Apply team coding and testing standards
```

---

## Tips
- Open all relevant files for best results.
- Use Copilot Chat to ask about cross-file logic and dependencies.
- Try Copilot’s suggestions, then review and refine as needed.

---
