// Before (SDK v2.5.0, deprecated getData with callbacks)
sdk.getData("resourceId", function(err, data) {
    if (err) {
        console.error("Error:", err);
        return;
    }
    console.log("Data:", data);
});

// After (SDK v3.0.0, modern async/await fetchDataAsync)
async function fetchResource() {
    try {
        const data = await sdk.fetchDataAsync("resourceId");
        console.log("Data:", data);
    } catch (err) {
        console.error("Error:", err);
    }
}
fetchResource();
