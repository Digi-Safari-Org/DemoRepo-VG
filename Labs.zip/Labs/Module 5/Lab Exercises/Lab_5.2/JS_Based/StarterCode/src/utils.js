// utils.js - Contains helper functions using outdated SDK methods

// Simulating an outdated SDK method
const sdk = {
    getData: (url, callback) => {
        setTimeout(() => {
            callback(null, { message: "Fake data from SDK v2.5.0", url });
        }, 500);
    }
};

function fetchData(url) {
    return new Promise((resolve, reject) => {
        sdk.getData(url, (err, data) => {
            if (err) reject(err);
            else resolve(data);
        });
    });
}

module.exports = { fetchData };
