// app.js - Example app using outdated SDK version

const { fetchData } = require('./utils');

async function main() {
    console.log("Starting application with SDK v2.5.0...");
    const data = await fetchData("https://api.example.com/data");
    console.log("Data received:", data);
}

main().catch(err => console.error("Error:", err));
