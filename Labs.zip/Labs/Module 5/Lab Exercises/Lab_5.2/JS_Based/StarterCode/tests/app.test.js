// app.test.js - Jest test for modernization verification

const { fetchData } = require('../src/utils');

test('fetchData should return expected data object', async () => {
    const data = await fetchData('https://api.example.com/test');
    expect(data).toHaveProperty('message');
    expect(data).toHaveProperty('url');
});
